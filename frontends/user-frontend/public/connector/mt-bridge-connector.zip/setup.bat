@echo off
REM MT Bridge Connector Setup
REM Installs Python dependencies for the pairing tool

echo ========================================
echo MT Bridge Connector Setup
echo ========================================
echo.

REM Check if Python is installed
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo ERROR: Python is not installed or not in PATH
    echo Please install Python 3.8+ from https://www.python.org/
    pause
    exit /b 1
)

echo Installing required dependencies...
python -m pip install --upgrade pip
python -m pip install requests

echo.
echo ========================================
echo Setup Complete!
echo ========================================
echo.
echo To pair your MT Bridge, run:
echo     python pair.py
echo.
pause

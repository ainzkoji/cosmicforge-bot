"""
MT Bridge Pairing Tool
Windows Connector script for pairing MT4/MT5 bridges with the platform.

Usage:
    python pair.py
"""
import requests
import json
import os
import sys
from pathlib import Path

# Configuration
PLATFORM_API_URL = os.getenv("PLATFORM_API_URL", "https://api.cosmicforge.app")
BRIDGE_CONFIG_FILE = "bridge_config.json"

def print_banner():
    print("=" * 60)
    print("  MT Bridge Pairing Tool")
    print("  CosmicForge Platform")
    print("=" * 60)
    print()

def load_bridge_config():
    """Load or create bridge configuration"""
    if os.path.exists(BRIDGE_CONFIG_FILE):
        with open(BRIDGE_CONFIG_FILE, 'r') as f:
            return json.load(f)
    return {}

def save_bridge_config(config):
    """Save bridge configuration"""
    with open(BRIDGE_CONFIG_FILE, 'w') as f:
        json.dump(config, f, indent=2)

def get_bridge_health(bridge_url, bridge_token, verify_ssl=False):
    """Test bridge connection and get account info"""
    try:
        response = requests.get(
            f"{bridge_url}/v1/health",
            headers={"Authorization": f"Bearer {bridge_token}"},
            verify=verify_ssl,
            timeout=10
        )
        response.raise_for_status()
        return response.json()
    except Exception as e:
        return None

def main():
    print_banner()
    
    # Step 1: Get pairing code from user
    print("[1/5] Enter Pairing Code")
    print("(Get this code from the CosmicForge platform)")
    pairing_code = input("\nPairing Code: ").strip().upper()
    
    if not pairing_code:
        print("❌ Error: Pairing code is required")
        return 1
    
    print()
    
    # Step 2: Get or configure bridge details
    print("[2/5] Bridge Configuration")
    config = load_bridge_config()
    
    if config.get("bridge_url") and config.get("bridge_token"):
        print(f"✓ Found existing bridge configuration")
        print(f"  URL: {config['bridge_url']}")
        use_existing = input("\nUse existing config? (y/n): ").strip().lower()
        if use_existing != 'y':
            config = {}
    
    if not config.get("bridge_url"):
        print("\nEnter your bridge URL:")
        print("  Example: https://your-vps.example.com:8443")
        config["bridge_url"] = input("Bridge URL: ").strip()
    
    if not config.get("bridge_token"):
        print("\nEnter your bridge API token:")
        print("  (Found in bridge_token.txt after generating)")
        config["bridge_token"] = input("API Token: ").strip()
    
    if not config.get("tls_mode"):
        print("\nTLS Verification Mode:")
        print("  1. Strict (Valid SSL certificate)")
        print("  2. Insecure (Self-signed certificate)")
        choice = input("Choice (1/2): ").strip()
        config["tls_mode"] = "strict" if choice == "1" else "insecure"
    
    save_bridge_config(config)
    print()
    
    # Step 3: Detect MT platform and account
    print("[3/5] Detecting MT Account...")
    
    verify_ssl = (config["tls_mode"] == "strict")
    health = get_bridge_health(config["bridge_url"], config["bridge_token"], verify_ssl)
    
    if not health:
        print("❌ Error: Cannot connect to bridge")
        print("   Make sure MT Bridge is running and accessible")
        return 1
    
    mt_platform = health.get("platform", "unknown")
    account_info = health.get("account", {})
    account_login = str(account_info.get("login", "unknown"))
    server = account_info.get("server", "unknown")
    
    print(f"✓ Detected: {mt_platform.upper()}")
    print(f"  Account: {account_login}")
    print(f"  Server: {server}")
    print()
    
    # Step 4: Complete pairing
    print("[4/5] Pairing with Platform...")
    
    try:
        response = requests.post(
            f"{PLATFORM_API_URL}/api/v1/mt/pair",
            json={
                "pairing_code": pairing_code,
                "bridge_url": config["bridge_url"],
                "bridge_token": config["bridge_token"],
                "tls_mode": config["tls_mode"],
                "mt_platform": mt_platform,
                "account_login": account_login,
                "server": server
            },
            timeout=15
        )
        
        if response.status_code == 200:
            result = response.json()
            print("✅ Pairing successful!")
            print(f"   Account ID: {result.get('account_id')}")
            print(f"   Message: {result.get('message')}")
            print()
        else:
            error_detail = response.json().get("detail", response.text)
            print(f"❌ Pairing failed: {error_detail}")
            return 1
    
    except requests.exceptions.RequestException as e:
        print(f"❌ Network error: {e}")
        print(f"   Could not reach platform at: {PLATFORM_API_URL}")
        return 1
    
    # Step 5: Success
    print("[5/5] Setup Complete!")
    print()
    print("Your MT bridge is now connected to CosmicForge.")
    print("Keep this bridge running to enable automated trading.")
    print()
    print("Next steps:")
    print("  1. Return to the CosmicForge platform")
    print("  2. Verify connection status")
    print("  3. Start trading!")
    
    return 0

if __name__ == "__main__":
    try:
        sys.exit(main())
    except KeyboardInterrupt:
        print("\n\n❌ Pairing cancelled by user")
        sys.exit(1)
    except Exception as e:
        print(f"\n\n❌ Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

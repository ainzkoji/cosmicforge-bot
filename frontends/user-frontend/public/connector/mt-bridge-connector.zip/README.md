# MT Bridge Windows Connector

## What is this?

The Windows Connector is a lightweight tool that pairs your local MT4/MT5 bridge with the CosmicForge platform using a simple pairing code.

## Quick Start

### Prerequisites

1. **Python 3.8+** installed on Windows
2. **MT4 or MT5** terminal running with Expert Advisor attached
3. **MT Bridge** server running (FastAPI + ZMQ)
4. **Active CosmicForge account**

### Installation

1. **Download the connector folder** to your Windows machine where MT terminal runs

2. **Run setup**:
   ```cmd
   setup.bat
   ```
   This installs Python dependencies (`requests` library)

3. **Generate pairing code** from the CosmicForge platform:
   - Go to "Connect Broker"
   - Select "MetaTrader 4" or "MetaTrader 5"
   - Click "Generate Pairing Code"
   - Copy the code (e.g., `ABCD-EF12`)

4. **Run the pairing tool**:
   ```cmd
   python pair.py
   ```

5. **Follow the prompts**:
   - Enter your pairing code
   - Provide bridge URL (e.g., `https://your-vps.example.com:8443`)
   - Provide bridge API token (from `bridge_token.txt`)
   - Select TLS mode (strict for valid certs, insecure for self-signed)

6. **Done!** Your bridge is now connected to CosmicForge

## File Structure

```
connector/
├── pair.py           # Main pairing script
├── setup.bat         # Windows setup script
├── README.md         # This file
└── bridge_config.json  # Auto-generated config (DO NOT share!)
```

## Configuration

The `bridge_config.json` file stores your bridge configuration:
- `bridge_url`: Your bridge endpoint
- `bridge_token`: API authentication token (SENSITIVE!)
- `tls_mode`: SSL verification mode

**⚠️ SECURITY WARNING**: This file contains your API token. Keep it secure and never share it.

## Troubleshooting

### "Cannot connect to bridge"
- Ensure MT terminal is running
- Ensure MT Bridge server is running (`python server/main.py`)
- Check bridge URL is correct and accessible
- Verify firewall allows connections to port 8443

### "Invalid pairing code"
- Pairing codes expire in 10 minutes
- Generate a new code from the platform

### "Platform mismatch"
- Ensure you selected the correct platform (MT4 vs MT5) when generating the code
- The pairing code is specific to one platform

### "Rate limit exceeded"
- You can only have 5 pending pairing sessions at once
- Wait for previous sessions to expire or complete

## Advanced: Custom Platform URL

By default, the connector connects to `https://api.cosmicforge.app`. For development or custom deployments:

```cmd
set PLATFORM_API_URL=https://your-custom-api.com
python pair.py
```

## Support

For issues or questions:
- Check MT Bridge logs: `mt-bridge/server/logs/`
- Contact support via the platform
- Review the main MT Bridge README

## Security Best Practices

1. **Use HTTPS**: Always use `https://` for your bridge URL
2. **Valid SSL Certificates**: Use "strict" TLS mode when possible
3. **Strong Tokens**: Use `scripts/generate_token.py` to create secure tokens
4. **Keep Bridge Private**: Don't expose bridge ports to the internet
5. **Regular Updates**: Keep MT Bridge software updated

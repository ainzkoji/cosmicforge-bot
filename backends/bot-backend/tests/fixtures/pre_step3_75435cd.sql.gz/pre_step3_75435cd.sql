BEGIN TRANSACTION;
CREATE TABLE account_equity_daily (
            broker_account_id TEXT NOT NULL, day TEXT NOT NULL, asset TEXT NOT NULL DEFAULT 'USDT',
            open REAL NOT NULL, high REAL NOT NULL, low REAL NOT NULL, close REAL NOT NULL,
            samples INTEGER NOT NULL, first_observed_at INTEGER NOT NULL, last_observed_at INTEGER NOT NULL,
            PRIMARY KEY(broker_account_id, day, asset));
CREATE TABLE account_equity_snapshots (
            snapshot_id TEXT PRIMARY KEY, user_id TEXT, broker_account_id TEXT NOT NULL, bot_instance_id TEXT,
            observed_at INTEGER NOT NULL, asset TEXT NOT NULL DEFAULT 'USDT',
            equity REAL NOT NULL, wallet REAL, available REAL, unrealized REAL,
            source TEXT NOT NULL, freshness_ms INTEGER, reason TEXT NOT NULL, dedupe_key TEXT NOT NULL UNIQUE);
CREATE TABLE adaptive_threshold_state (
            bot_instance_id TEXT NOT NULL,
            symbol TEXT NOT NULL,
            timeframe TEXT NOT NULL,
            strategy_version TEXT NOT NULL,
            previous_threshold REAL,
            last_candle_time INTEGER,
            distribution_samples_json TEXT,
            updated_at TEXT,
            engine_version TEXT,
            policy_hash TEXT,
            PRIMARY KEY (bot_instance_id, symbol, timeframe, strategy_version)
        );
CREATE TABLE admin_roles (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    role TEXT NOT NULL DEFAULT 'admin',
                    granted_by TEXT,
                    granted_at TEXT NOT NULL,
                    revoked_at TEXT,
                    FOREIGN KEY(user_id) REFERENCES users(id)
                );
CREATE TABLE admin_sessions (
                    id TEXT PRIMARY KEY,
                    admin_id TEXT NOT NULL,
                    refresh_token_hash TEXT NOT NULL,
                    device TEXT,
                    ip TEXT,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    revoked_at TEXT,
                    rotated_from TEXT,
                    FOREIGN KEY (admin_id) REFERENCES admins(id)
                );
CREATE TABLE admins (
                    id TEXT PRIMARY KEY,
                    email TEXT UNIQUE NOT NULL,
                    hashed_password TEXT NOT NULL,
                    full_name TEXT,
                    role TEXT NOT NULL DEFAULT 'admin',
                    is_active INTEGER DEFAULT 1,
                    is_superuser INTEGER DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    last_login_at TEXT
                );
CREATE TABLE affiliate_settings (
                    id TEXT PRIMARY KEY DEFAULT 'global',
                    referral_commission_rate REAL NOT NULL DEFAULT 15.0,
                    cookie_duration_days INTEGER NOT NULL DEFAULT 30,
                    minimum_payout_amount REAL NOT NULL DEFAULT 100.0,
                    minimum_payout_currency TEXT NOT NULL DEFAULT 'USD',
                    tiered_referrals_enabled INTEGER NOT NULL DEFAULT 0,
                    attribution_model TEXT NOT NULL DEFAULT 'last_click',
                    is_enabled INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL
                );
CREATE TABLE alerts (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts TEXT NOT NULL,
                    alert_type TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    trace_id TEXT,
                    symbol TEXT,
                    message TEXT,
                    details_json TEXT,
                    acknowledged INTEGER DEFAULT 0,
                    acknowledged_at TEXT,
                    acknowledged_by TEXT,
                    -- Added fields (auto-migrated below)
                    user_id TEXT,
                    bot_instance_id TEXT,
                    broker_account_id TEXT
                );
CREATE TABLE aml_alerts (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    alert_type TEXT,
                    severity TEXT,
                    description TEXT,
                    status TEXT DEFAULT 'open',
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(user_id) REFERENCES users(id)
                );
CREATE TABLE analytics_cache (
                    cache_key TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    bot_instance_id TEXT,
                    broker_account_id TEXT,
                    timeframe TEXT,
                    computed_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL,
                    metrics_json TEXT NOT NULL
                );
CREATE TABLE auth_audit_log (
                    id TEXT PRIMARY KEY,
                    event_type TEXT NOT NULL,
                    user_id TEXT,
                    email TEXT,
                    ip TEXT,
                    details TEXT,
                    created_at TEXT NOT NULL
                );
CREATE TABLE auth_sessions (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                refresh_token_hash TEXT NOT NULL,
                device TEXT,
                ip TEXT,
                created_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                revoked_at TEXT,
                rotated_from TEXT,
                FOREIGN KEY (user_id) REFERENCES users(id)
            );
CREATE TABLE backtest_decision_logs (
                id TEXT PRIMARY KEY,
                run_id TEXT NOT NULL,
                timestamp_utc TEXT NOT NULL,
                symbol TEXT NOT NULL,
                
                -- Decision pipeline
                strategy_signal_json TEXT,
                risk_gate_decision_json TEXT,
                sizing_decision_json TEXT,
                protection_decision_json TEXT,
                final_action TEXT,
                execution_result_json TEXT,
                
                -- Context
                candle_index INTEGER,
                
                FOREIGN KEY(run_id) REFERENCES backtest_runs(id)
            );
CREATE TABLE backtest_equity_curve (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id TEXT NOT NULL,
                timestamp_utc TEXT NOT NULL,
                
                -- Equity metrics
                equity REAL NOT NULL,
                balance REAL NOT NULL,
                unrealized_pnl REAL DEFAULT 0.0,
                realized_pnl REAL DEFAULT 0.0,
                
                -- Risk metrics
                drawdown_pct REAL,
                drawdown_usdt REAL,
                peak_equity REAL,
                
                -- Multi-currency
                quote_currency TEXT DEFAULT 'USDT', metadata_json TEXT,
                
                FOREIGN KEY(run_id) REFERENCES backtest_runs(id)
            );
CREATE TABLE backtest_fills (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id TEXT NOT NULL,
                timestamp_utc TEXT NOT NULL,
                
                -- Trade details
                symbol TEXT NOT NULL,
                side TEXT NOT NULL,
                quantity REAL NOT NULL,
                entry_price REAL NOT NULL,
                fill_price REAL NOT NULL,
                fee_usdt REAL DEFAULT 0.0,
                slippage_usdt REAL DEFAULT 0.0,
                pnl REAL,
                
                -- Context
                strategy TEXT,
                confidence REAL,
                position_state TEXT,
                trade_type TEXT,
                
                -- Multi-currency support
                quote_currency TEXT DEFAULT 'USDT', metadata_json TEXT,
                
                FOREIGN KEY(run_id) REFERENCES backtest_runs(id)
            );
CREATE TABLE backtest_jobs (
                id TEXT PRIMARY KEY,
                user_id TEXT,
                run_id TEXT NOT NULL,
                
                -- Job configuration
                status TEXT NOT NULL DEFAULT 'pending',
                priority INTEGER DEFAULT 5,
                config_json TEXT NOT NULL,
                
                -- Token claiming (SQLite-safe concurrency)
                processing_token TEXT,
                processing_started_at TEXT,
                attempts INTEGER DEFAULT 0,
                next_retry_at TEXT,
                last_error TEXT,
                
                -- Progress tracking
                progress_pct REAL DEFAULT 0.0,
                current_candle INTEGER,
                total_candles INTEGER,
                
                -- Results
                result_json TEXT,
                
                -- Timestamps
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                completed_at TEXT,
                
                FOREIGN KEY(user_id) REFERENCES users(id),
                FOREIGN KEY(run_id) REFERENCES backtest_runs(id)
            );
CREATE TABLE backtest_performance (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id TEXT NOT NULL,
                symbol TEXT NOT NULL,
                
                -- Trade statistics
                total_trades INTEGER DEFAULT 0,
                wins INTEGER DEFAULT 0,
                losses INTEGER DEFAULT 0,
                win_rate REAL,
                
                -- PnL metrics
                gross_pnl REAL,
                net_pnl REAL,
                total_fees REAL,
                avg_win REAL,
                avg_loss REAL,
                largest_win REAL,
                largest_loss REAL,
                
                -- Risk metrics
                max_drawdown REAL,
                avg_trade_duration_minutes REAL,
                sharpe_ratio REAL,
                profit_factor REAL,
                expectancy REAL,
                
                -- Multi-currency
                quote_currency TEXT DEFAULT 'USDT',
                
                FOREIGN KEY(run_id) REFERENCES backtest_runs(id),
                UNIQUE(run_id, symbol)
            );
CREATE TABLE backtest_runs (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                name TEXT NOT NULL,
                
                -- Strategy configuration
                strategy_id TEXT NOT NULL,
                strategy_version TEXT,
                symbols_json TEXT NOT NULL,
                timeframe TEXT NOT NULL,
                start_date TEXT NOT NULL,
                end_date TEXT NOT NULL,
                
                -- Multi-asset support (forex-ready)
                market_type TEXT NOT NULL DEFAULT 'crypto',
                base_currency TEXT,
                quote_currency TEXT NOT NULL DEFAULT 'USDT',
                
                -- Capital & risk settings
                initial_capital REAL NOT NULL,
                leverage INTEGER,
                strategy_params_json TEXT,
                risk_params_json TEXT,
                slippage_bps REAL DEFAULT 10.0,
                fee_bps REAL DEFAULT 6.0,
                
                -- Data source tracking (reproducibility)
                data_source TEXT NOT NULL,
                data_version TEXT,
                seed INTEGER,
                
                -- Results
                status TEXT NOT NULL DEFAULT 'pending',
                progress_pct REAL DEFAULT 0.0,
                total_trades INTEGER DEFAULT 0,
                win_rate REAL,
                net_pnl REAL,
                gross_pnl REAL,
                total_fees REAL,
                max_drawdown REAL,
                sharpe_ratio REAL,
                sortino_ratio REAL,
                calmar_ratio REAL,
                profit_factor REAL,
                error_message TEXT,
                
                -- Timestamps
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                completed_at TEXT,
                
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
CREATE TABLE benchmark_prices (
                    symbol TEXT NOT NULL,
                    date TEXT NOT NULL,
                    close_price REAL NOT NULL,
                    quote_currency TEXT DEFAULT 'USD',
                    asset_class TEXT,
                    provider TEXT,
                    updated_at TEXT,
                    PRIMARY KEY (symbol, date)
                );
CREATE TABLE billing_customers (
            user_id TEXT NOT NULL,
            mode TEXT NOT NULL DEFAULT 'live',
            provider TEXT NOT NULL DEFAULT 'stripe',
            provider_customer_id TEXT NOT NULL,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            PRIMARY KEY (user_id, mode)
        );
CREATE TABLE billing_events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    event_id TEXT,                  -- provider event id
                    event_type TEXT NOT NULL,       -- checkouts.session.completed, etc
                    provider TEXT DEFAULT 'stripe',
                    payload_json TEXT,
                    processed_at TEXT,
                    created_at TEXT NOT NULL
                , result TEXT);
CREATE TABLE bot_candle_evaluations (
                    bot_instance_id TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    timeframe TEXT NOT NULL,
                    last_closed_candle_time INTEGER NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (bot_instance_id, symbol, timeframe)
                );
CREATE TABLE bot_daily_close_marks (
                    bot_instance_id TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    close_window TEXT NOT NULL,
                    position_id TEXT,
                    closed_at TEXT NOT NULL,
                    reason TEXT NOT NULL DEFAULT 'DAILY_CLOSE',
                    PRIMARY KEY (bot_instance_id, symbol, close_window)
                );
CREATE TABLE bot_daily_state (
                    bot_instance_id TEXT NOT NULL,
                    day TEXT NOT NULL,
                    realized_pnl REAL DEFAULT 0.0,
                    kill INTEGER DEFAULT 0,
                    trade_count INTEGER DEFAULT 0,
                    last_updated_at TEXT, consecutive_losses INTEGER DEFAULT 0, consec_loss_cooldown_until_ms INTEGER DEFAULT 0,
                    PRIMARY KEY (bot_instance_id, day)
                );
CREATE TABLE bot_instances (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    broker_account_id TEXT NOT NULL,
                    market_type TEXT NOT NULL,
                    strategy_id TEXT NOT NULL,
                    strategy_version TEXT,
                    config_id TEXT,
                    risk_profile_id TEXT,
                    
                    symbols JSON,
                    timeframes JSON,
                    
                    allocation_type TEXT,
                    allocation_value REAL,
                    
                    mode TEXT NOT NULL,
                    status TEXT NOT NULL,
                    
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    started_at TEXT,
                    stopped_at TEXT,
                    
                    last_run_at TEXT,
                    last_run_id TEXT,
                    last_error TEXT, risk_level TEXT DEFAULT 'balanced', capital_allocation REAL, capital_allocation_type TEXT DEFAULT 'fixed_amount', symbols_json TEXT DEFAULT '[]', timeframes_json TEXT DEFAULT '["15m"]', total_trades INTEGER DEFAULT 0, active_positions INTEGER DEFAULT 0, bot_health_status TEXT DEFAULT 'UNKNOWN', bot_health_message TEXT, bot_health_reason_code TEXT, bot_health_recommended_action TEXT, bot_health_updated_at TEXT, last_warning TEXT, risk_profile_version TEXT, max_position_usdt REAL, risk_acknowledged_at TEXT, deploy_request_id TEXT, stopped_reason TEXT, broker_health_status TEXT DEFAULT 'ok', broker_error_code TEXT, broker_blocked_at TEXT, block_category TEXT, block_reason_code TEXT, block_reason_detail TEXT, blocked_since TEXT, last_validated_at TEXT, last_validation_error TEXT, universe_mode TEXT, daily_loss_limit_pct REAL,
                    
                    FOREIGN KEY(user_id) REFERENCES users(id),
                    FOREIGN KEY(broker_account_id) REFERENCES broker_accounts(id)
                );
CREATE TABLE bot_runs (
            run_id TEXT PRIMARY KEY,
            runtime_session_id TEXT,
            bot_instance_id TEXT NOT NULL,
            user_id TEXT,
            policy_hash TEXT,
            provenance TEXT NOT NULL DEFAULT 'PAPER_FORWARD',
            execution_mode TEXT,
            broker_environment TEXT,
            started_at TEXT NOT NULL,
            ended_at TEXT,
            status TEXT NOT NULL DEFAULT 'RUNNING',
            cycles INTEGER NOT NULL DEFAULT 0,
            decisions INTEGER NOT NULL DEFAULT 0,
            attempts INTEGER NOT NULL DEFAULT 0,
            fills INTEGER NOT NULL DEFAULT 0,
            positions_opened INTEGER NOT NULL DEFAULT 0,
            positions_closed INTEGER NOT NULL DEFAULT 0,
            primary_failure_reason TEXT
        );
CREATE TABLE bot_symbol_state (
                    bot_instance_id TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    position TEXT NOT NULL,
                    entry_price REAL,
                    last_signal TEXT NOT NULL,
                    last_action TEXT NOT NULL,
                    last_checked_ms INTEGER NOT NULL,
                    adds INTEGER NOT NULL,
                    last_trade_ms INTEGER NOT NULL,
                    pending_open TEXT NOT NULL,
                    entry_qty REAL NOT NULL,
                    last_user_trade_id INTEGER NOT NULL DEFAULT 0,
                    last_stop_ms INTEGER NOT NULL DEFAULT 0,
                    reentry_confirm_signal TEXT NOT NULL DEFAULT 'NONE',
                    reentry_confirm_count INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL, position_id TEXT, lifecycle_phase TEXT DEFAULT 'SEEKING_TP1', lifecycle_current_stop REAL, lifecycle_original_stop REAL, lifecycle_is_be INTEGER DEFAULT 0, lifecycle_tp1_hit INTEGER DEFAULT 0, lifecycle_sl_order_id TEXT, lifecycle_tp_order_id TEXT,
                    PRIMARY KEY (bot_instance_id, symbol),
                    FOREIGN KEY(bot_instance_id) REFERENCES bot_instances(id)
                );
CREATE TABLE bot_system_events (
                    event_id TEXT PRIMARY KEY,
                    bot_instance_id TEXT,
                    user_id TEXT,
                    run_id TEXT,
                    event_type TEXT NOT NULL,
                    severity TEXT NOT NULL DEFAULT 'INFO',
                    reason_code TEXT,
                    message TEXT,
                    details_json TEXT NOT NULL DEFAULT '{}',
                    provenance TEXT NOT NULL DEFAULT 'RUNTIME',
                    created_at TEXT NOT NULL
                );
CREATE TABLE broker_accounts (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    broker_id TEXT NOT NULL,        -- binance, bybit, etc.
                    market_type TEXT NOT NULL,      -- crypto, forex, stocks
                    label TEXT,
                    status TEXT NOT NULL,           -- draft, validating, connected, restricted, disconnected, disabled
                    environment TEXT DEFAULT 'live',-- live, demo
                    account_type TEXT,              -- spot, futures
                    capabilities JSON,              -- read, trade, margin, etc.
                    masked_key TEXT,                -- first4..last4
                    last_validated_at TEXT,
                    last_error_code TEXT,
                    last_error_message TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                , active_credential_version INTEGER, validation_error TEXT, superseded_at TEXT, permission_status TEXT);
CREATE TABLE broker_audit_log (
                    id TEXT PRIMARY KEY,
                    broker_account_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,       -- connected, credentials_updated, validation_failed
                    details_json TEXT,
                    ip_address TEXT,
                    timestamp_utc TEXT NOT NULL,
                    FOREIGN KEY(broker_account_id) REFERENCES broker_accounts(id)
                );
CREATE TABLE broker_credentials (
                    account_id TEXT PRIMARY KEY,
                    encrypted_blob TEXT NOT NULL,
                    key_metadata TEXT,              -- version, algo, etc.
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY(account_id) REFERENCES broker_accounts(id)
                );
CREATE TABLE broker_credentials_v2 (
                id                  INTEGER PRIMARY KEY AUTOINCREMENT,
                account_id          TEXT NOT NULL,
                version             INTEGER NOT NULL DEFAULT 1,
                status              TEXT NOT NULL DEFAULT 'active',
                encrypted_blob      TEXT NOT NULL,
                key_metadata        TEXT,
                key_fingerprint     TEXT,
                created_at          TEXT NOT NULL,
                updated_at          TEXT NOT NULL,
                superseded_at       TEXT,
                last_validated_at   TEXT,
                validation_error    TEXT, permissions_json TEXT,
                UNIQUE (account_id, version),
                FOREIGN KEY(account_id) REFERENCES broker_accounts(id)
            );
CREATE TABLE broker_transfer_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    transfer_id TEXT NOT NULL,
    user_id TEXT NOT NULL,
    broker_account_id TEXT NOT NULL,
    event_type TEXT NOT NULL,
    from_status TEXT,
    to_status TEXT,
    detail_json TEXT,
    created_at TEXT NOT NULL
);
CREATE TABLE broker_transfer_reconciliations (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    broker_account_id TEXT NOT NULL,
    broker TEXT NOT NULL,
    run_at TEXT NOT NULL,
    history_rows INTEGER NOT NULL DEFAULT 0,
    matched INTEGER NOT NULL DEFAULT 0,
    completed INTEGER NOT NULL DEFAULT 0,
    failed INTEGER NOT NULL DEFAULT 0,
    still_unresolved INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL,
    detail_json TEXT
);
CREATE TABLE broker_transfer_requests (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    broker_account_id TEXT NOT NULL,
    broker TEXT NOT NULL,
    environment TEXT NOT NULL,
    credential_version INTEGER,
    asset TEXT NOT NULL,
    amount TEXT NOT NULL,
    source_wallet TEXT NOT NULL,
    destination_wallet TEXT NOT NULL,
    source_venue_wallet TEXT,
    destination_venue_wallet TEXT,
    broker_transfer_id TEXT,
    idempotency_key TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('REQUESTED', 'VALIDATING', 'BLOCKED', 'SUBMITTING', 'SUBMITTED', 'CONFIRMATION_PENDING', 'COMPLETED', 'FAILED', 'UNKNOWN', 'RECONCILIATION_REQUIRED')),
    failure_reason TEXT,
    origin TEXT NOT NULL DEFAULT 'MANUAL',
    requested_at TEXT NOT NULL,
    submitted_at TEXT,
    confirmed_at TEXT,
    last_reconciled_at TEXT,
    reconcile_attempts INTEGER NOT NULL DEFAULT 0,
    metadata_json TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    UNIQUE (user_id, broker_account_id, idempotency_key),
    FOREIGN KEY (broker_account_id) REFERENCES broker_accounts(id)
);
CREATE TABLE broker_transfer_settings (
    broker_account_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    mode TEXT NOT NULL DEFAULT 'MANUAL_TRANSFER'
        CHECK (mode IN ('MANUAL_TRANSFER', 'AUTOMATED_INTERNAL_REALLOCATION')),
    auto_rebalance_enabled INTEGER NOT NULL DEFAULT 0,
    max_transfer_amount TEXT,
    min_funding_balance TEXT,
    min_derivatives_reserve TEXT,
    min_free_margin TEXT,
    asset_allowlist_json TEXT,
    wallet_allowlist_json TEXT,
    daily_transfer_limit TEXT,
    authorized_at TEXT,
    updated_at TEXT NOT NULL
, allowed_routes_json TEXT, max_transfer_pct TEXT, max_destination_balance TEXT, manual_approval_threshold TEXT, emergency_disabled INTEGER NOT NULL DEFAULT 0);
CREATE TABLE broker_transfers_cache (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    broker_account_id TEXT NOT NULL,
                    broker_id TEXT NOT NULL,
                    ts_utc TEXT NOT NULL,
                    type TEXT NOT NULL,
                    asset TEXT NOT NULL,
                    amount REAL NOT NULL,
                    status TEXT,
                    fee REAL,
                    network TEXT,
                    txid TEXT,
                    raw_id TEXT,
                    raw_json TEXT,
                    created_at TEXT NOT NULL, classification TEXT, direction TEXT, source_wallet TEXT, destination_wallet TEXT, transfer_request_id TEXT,
                    UNIQUE(broker_account_id, type, raw_id)
                );
CREATE TABLE canonical_trade_decisions (
                    decision_id TEXT PRIMARY KEY,
                    cycle_id TEXT,
                    run_id TEXT,
                    bot_instance_id TEXT,
                    user_id TEXT,
                    symbol TEXT NOT NULL,
                    timeframe TEXT,
                    candle_open_time INTEGER,
                    candle_close_time INTEGER,
                    decision_timestamp TEXT NOT NULL,
                    final_action TEXT NOT NULL,
                    primary_reason_code TEXT NOT NULL,
                    secondary_reason_codes_json TEXT NOT NULL,
                    confidence REAL,
                    effective_entry_threshold REAL,
                    order_id TEXT,
                    executor_status TEXT,
                    executor_error TEXT,
                    effective_policy_hash TEXT,
                    signal_source TEXT NOT NULL DEFAULT 'INTERNAL_MASTER_ENSEMBLE',
                    complete INTEGER NOT NULL DEFAULT 0,
                    decision_json TEXT NOT NULL,
                    provenance TEXT
                );
CREATE TABLE cati_capital_plan_evidence (
    evidence_id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    broker_account_id TEXT NOT NULL,
    bot_instance_id TEXT,
    cycle_id TEXT,
    opportunity_id TEXT,
    mode TEXT NOT NULL DEFAULT 'SHADOW',
    outcome TEXT NOT NULL,
    product TEXT NOT NULL,
    plan_json TEXT NOT NULL,
    simulated_transfer_json TEXT,
    created_at INTEGER NOT NULL
, topology_json TEXT, balances_json TEXT);
CREATE TABLE cati_certification_runs (
    certification_run_id TEXT PRIMARY KEY,
    stage TEXT NOT NULL,
    status TEXT NOT NULL,
    scope_hash TEXT NOT NULL,
    dataset_hash TEXT NOT NULL,
    policy_freeze_hash TEXT NOT NULL,
    certification_policy_hash TEXT NOT NULL,
    artifact_hash TEXT NOT NULL,
    recorded_at INTEGER NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE cati_certification_stage_results (
    stage_result_id TEXT PRIMARY KEY,
    certification_run_id TEXT NOT NULL,
    stage TEXT NOT NULL,
    status TEXT NOT NULL,
    recorded_at INTEGER NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE cati_component_errors (
    error_id TEXT PRIMARY KEY,
    component TEXT NOT NULL,
    stage TEXT,
    exception_class TEXT NOT NULL,
    cycle_id TEXT,
    user_id TEXT,
    broker_account_id TEXT,
    bot_instance_id TEXT,
    observed_at INTEGER NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE cati_decision_evidence (
    decision_evidence_id TEXT PRIMARY KEY,
    economic_opportunity_id TEXT NOT NULL,
    forecast_id TEXT NOT NULL,
    veto_decision_id TEXT NOT NULL,
    setup_candidate_id TEXT NOT NULL,
    market_state_id TEXT NOT NULL,
    user_id TEXT,
    broker_account_id TEXT NOT NULL,
    bot_instance_id TEXT NOT NULL,
    decision_time INTEGER NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE cati_execution_attempts (
    record_id TEXT PRIMARY KEY,
    execution_attempt_id TEXT NOT NULL,
    sequence INTEGER NOT NULL,
    trade_plan_id TEXT NOT NULL,
    risk_decision_id TEXT,
    user_id TEXT,
    broker_account_id TEXT NOT NULL,
    bot_instance_id TEXT NOT NULL,
    position_id TEXT,
    status TEXT NOT NULL,
    broker_order_id TEXT,
    recorded_at INTEGER NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL,
    UNIQUE (execution_attempt_id, sequence)
);
CREATE TABLE cati_exit_decisions (
    exit_decision_id TEXT PRIMARY KEY,
    position_forecast_id TEXT NOT NULL,
    position_id TEXT NOT NULL,
    trade_plan_id TEXT NOT NULL,
    user_id TEXT,
    broker_account_id TEXT NOT NULL,
    bot_instance_id TEXT NOT NULL,
    decision_time INTEGER NOT NULL,
    action TEXT NOT NULL CHECK (action IN ('HOLD','REDUCE','EXIT','TIGHTEN_PROTECTION','TAKE_PARTIAL','NO_CHANGE_FALLBACK')),
    requested_fraction REAL,
    suggested_protection_price REAL,
    thesis_status TEXT NOT NULL,
    evaluation_mode TEXT NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE cati_experiment_registry (
    experiment_id TEXT PRIMARY KEY,
    parent_experiment_id TEXT,
    dataset_hash TEXT NOT NULL,
    policy_hash TEXT NOT NULL,
    status TEXT NOT NULL,
    created_at INTEGER NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE cati_global_market_states (
    evidence_id TEXT PRIMARY KEY,
    global_state_id TEXT NOT NULL,
    state_hash TEXT NOT NULL,
    decision_time INTEGER NOT NULL,
    timeframe TEXT NOT NULL,
    asset_classes TEXT NOT NULL,
    risk_regime TEXT,
    input_count INTEGER NOT NULL,
    cycle_id TEXT,
    bot_instance_id TEXT,
    broker_account_id TEXT,
    schema_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    recorded_at INTEGER NOT NULL
);
CREATE TABLE cati_governance_controls (
    control_event_id TEXT PRIMARY KEY,
    control TEXT NOT NULL,
    state TEXT NOT NULL CHECK (state IN ('ON', 'OFF')),
    scope TEXT NOT NULL,
    recorded_at INTEGER NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE cati_holdout_registry (
    holdout_event_id TEXT PRIMARY KEY,
    holdout_id TEXT NOT NULL,
    dataset_hash TEXT NOT NULL,
    event TEXT NOT NULL CHECK (event IN ('RESERVED', 'OPENED', 'BURNED')),
    policy_freeze_hash TEXT,
    recorded_at INTEGER NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE cati_ml_model_events (
    model_event_id TEXT PRIMARY KEY,
    model_id TEXT NOT NULL,
    from_status TEXT,
    to_status TEXT NOT NULL,
    recorded_at INTEGER NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE cati_ml_models (
    model_id TEXT PRIMARY KEY,
    role TEXT NOT NULL,
    artifact_hash TEXT NOT NULL,
    training_dataset_hash TEXT NOT NULL,
    feature_schema_hash TEXT NOT NULL,
    label_schema_hash TEXT NOT NULL,
    code_commit TEXT,
    supersedes_model_id TEXT,
    created_at INTEGER NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE cati_ml_shadow_predictions (
    prediction_id TEXT PRIMARY KEY,
    model_id TEXT NOT NULL,
    role TEXT NOT NULL,
    market_state_id TEXT,
    setup_candidate_id TEXT,
    decision_time INTEGER NOT NULL,
    recorded_at INTEGER NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE cati_portfolio_reservations (
    reservation_id TEXT PRIMARY KEY,
    broker_account_id TEXT NOT NULL,
    bot_instance_id TEXT NOT NULL,
    cycle_id TEXT NOT NULL,
    selected_candidate_ids TEXT NOT NULL,
    selected_instruments TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('RESERVED', 'RESOLUTION_PENDING', 'CONSUMED', 'RELEASED', 'EXPIRED')),
    mode TEXT NOT NULL DEFAULT 'SHADOW',
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    updated_at INTEGER NOT NULL,
    reservation_version TEXT NOT NULL,
    policy_version TEXT,
    policy_hash TEXT,
    payload_hash TEXT,
    capacity_snapshot TEXT,
    trade_plan_id TEXT,
    execution_attempt_id TEXT,
    pending_since INTEGER,
    resolution_deadline INTEGER,
    resolution_note TEXT,
    user_id TEXT,
    capital_asset TEXT,
    capital_amount TEXT,
    capital_wallet TEXT,
    capital_json TEXT
);
CREATE TABLE cati_position_forecasts (
    position_forecast_id TEXT PRIMARY KEY,
    position_id TEXT NOT NULL,
    trade_plan_id TEXT NOT NULL,
    position_path_id TEXT NOT NULL,
    market_state_id TEXT,
    regime_distribution_id TEXT,
    user_id TEXT,
    broker_account_id TEXT NOT NULL,
    bot_instance_id TEXT NOT NULL,
    forecast_time INTEGER NOT NULL,
    status TEXT NOT NULL,
    thesis_status TEXT NOT NULL,
    conservative_remaining_edge_r REAL NOT NULL,
    evaluation_mode TEXT NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE cati_promotion_phase_history (
    transition_id TEXT PRIMARY KEY,
    from_phase TEXT NOT NULL,
    to_phase TEXT NOT NULL,
    scope_hash TEXT NOT NULL,
    source_commit TEXT,
    certification_run_id TEXT,
    policy_freeze_hash TEXT,
    requested_at INTEGER NOT NULL,
    approved_at INTEGER,
    recorded_at INTEGER NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE cati_promotion_scopes (
    scope_event_id TEXT PRIMARY KEY,
    scope_hash TEXT NOT NULL,
    event TEXT NOT NULL CHECK (event IN ('GRANTED', 'REVOKED')),
    broker_account_id TEXT NOT NULL,
    venue TEXT NOT NULL,
    environment TEXT NOT NULL,
    recorded_at INTEGER NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE cati_risk_decisions (
    risk_decision_id TEXT PRIMARY KEY,
    trade_plan_id TEXT NOT NULL,
    trade_plan_hash TEXT NOT NULL,
    user_id TEXT,
    broker_account_id TEXT NOT NULL,
    bot_instance_id TEXT NOT NULL,
    runtime_session_id TEXT,
    run_id TEXT,
    cycle_id TEXT,
    status TEXT NOT NULL CHECK (status IN ('APPROVED','REJECTED')),
    rejection_family TEXT,
    decision_time INTEGER NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE cati_trade_plans (
    trade_plan_id TEXT PRIMARY KEY,
    trade_plan_hash TEXT NOT NULL,
    user_id TEXT,
    broker_account_id TEXT NOT NULL,
    bot_instance_id TEXT NOT NULL,
    run_id TEXT,
    cycle_id TEXT NOT NULL,
    candidate_id TEXT NOT NULL,
    economic_opportunity_id TEXT NOT NULL,
    portfolio_decision_id TEXT NOT NULL,
    reservation_id TEXT NOT NULL,
    canonical_symbol TEXT NOT NULL,
    venue TEXT NOT NULL,
    environment TEXT NOT NULL,
    side TEXT NOT NULL,
    mode TEXT NOT NULL DEFAULT 'SHADOW',
    created_at INTEGER NOT NULL,
    expires_at INTEGER NOT NULL,
    schema_version TEXT NOT NULL,
    table_version TEXT NOT NULL,
    payload TEXT NOT NULL,
    payload_hash TEXT NOT NULL
);
CREATE TABLE commission_config (
                    id TEXT PRIMARY KEY,            -- 'global' or plan_id
                    percentage REAL NOT NULL,       -- 0.1 = 10%
                    cap_amount REAL,                -- max per trade?
                    currency TEXT DEFAULT 'USD',
                    updated_at TEXT NOT NULL
                );
CREATE TABLE commission_ledger (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    trade_id TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    plan_id TEXT,
                    
                    trade_pnl REAL,
                    commission_amount REAL,
                    currency TEXT,
                    
                    status TEXT NOT NULL,           -- pending, realized, invoiced
                    invoice_id TEXT,
                    
                    created_at TEXT NOT NULL
                );
CREATE TABLE commission_tiers (
                    id TEXT PRIMARY KEY,
                    name TEXT,
                    min_volume REAL,
                    max_volume REAL,
                    rate REAL,
                    is_active INTEGER DEFAULT 1,
                    created_at TEXT,
                    updated_at TEXT
                );
CREATE TABLE cycle_decision_summaries (
                    cycle_id TEXT PRIMARY KEY,
                    run_id TEXT,
                    bot_instance_id TEXT,
                    created_at TEXT NOT NULL,
                    summary_json TEXT NOT NULL
                );
CREATE TABLE daily_close_validation_reports (
                id TEXT PRIMARY KEY,
                bot_instance_id TEXT NOT NULL,
                run_id TEXT,
                environment TEXT,
                daily_close_enabled INTEGER,
                window_start TEXT,
                window_end TEXT,
                position_opened_at TEXT,
                position_symbol TEXT,
                position_side TEXT,
                entry_price REAL,
                close_trigger_time TEXT,
                close_price REAL,
                exit_reason TEXT,
                close_fill_id INTEGER,
                gross_pnl REAL,
                fees REAL,
                slippage REAL,
                net_pnl REAL,
                audit_event_written INTEGER,
                state_reset_confirmed INTEGER,
                validation_status TEXT,
                errors_json TEXT,
                validated_at TEXT
            );
CREATE TABLE daily_state (
                    day TEXT PRIMARY KEY,
                    realized_pnl REAL DEFAULT 0.0,
                    kill INTEGER DEFAULT 0,
                    trade_count INTEGER DEFAULT 0,
                    last_updated_at TEXT
                , consecutive_losses INTEGER DEFAULT 0, consec_loss_cooldown_until_ms INTEGER DEFAULT 0);
CREATE TABLE data_quality_events (
            event_id TEXT PRIMARY KEY,
            event_type TEXT NOT NULL,
            severity TEXT NOT NULL DEFAULT 'WARNING',
            bot_instance_id TEXT,
            run_id TEXT,
            cycle_id TEXT,
            decision_id TEXT,
            subject_id TEXT,
            detected_at TEXT NOT NULL,
            detail TEXT,
            resolved_at TEXT,
            resolution TEXT
        );
CREATE TABLE database_registry (
            database_path TEXT PRIMARY KEY,
            classification TEXT NOT NULL,
            database_role TEXT,
            size_bytes INTEGER,
            modified_at TEXT,
            schema_version INTEGER,
            registered_at TEXT NOT NULL,
            note TEXT
        );
CREATE TABLE dataset_manifests (
        manifest_id TEXT PRIMARY KEY,
        manifest_hash TEXT NOT NULL UNIQUE,
        role TEXT NOT NULL,
        asset_class TEXT NOT NULL,
        venue TEXT NOT NULL,
        payload_json TEXT NOT NULL,
        created_at INTEGER NOT NULL
    );
CREATE TABLE decision_logs (
                id TEXT PRIMARY KEY,
                config_id TEXT NOT NULL,
                run_id TEXT,
                symbol TEXT NOT NULL,
                strategy_signal_json TEXT,  -- Raw strategy output
                risk_gate_decision_json TEXT, -- Pre-trade gate result
                sizing_decision_json TEXT, -- Sizing engine calculation
                protection_decision_json TEXT, -- Protective order validation
                final_action TEXT, -- EXECUTE, BLOCK, SKIP
                execution_result_json TEXT, -- If executed, the result
                created_at TEXT NOT NULL,
                FOREIGN KEY(config_id) REFERENCES user_strategy_configs(id)
            );
CREATE TABLE decision_traces (
                    trace_id TEXT PRIMARY KEY,
                    run_id TEXT,
                    cycle_id TEXT,
                    position_id TEXT,
                    account_id TEXT,
                    environment TEXT,
                    symbol TEXT,
                    timeframe TEXT,
                    ts TEXT,
                    
                    -- Market snapshot
                    last_price REAL,
                    mark_price REAL,
                    
                    -- Risk snapshot
                    equity REAL,
                    margin_used REAL,
                    margin_level REAL,
                    drawdown_pct REAL,
                    open_positions_count INTEGER,
                    
                    -- Always-On Risk (Added)
                    regime_state TEXT DEFAULT 'UNKNOWN',
                    regime_confidence REAL DEFAULT 0.0,
                    exposure_freeze INTEGER DEFAULT 0,
                    kill_switch_state TEXT DEFAULT 'NORMAL',
                    portfolio_risk_budget REAL DEFAULT 0.0,
                    portfolio_risk_used REAL DEFAULT 0.0,
                    
                    -- Strategy outputs (JSON array)
                    strategy_signals_json TEXT,
                    chosen_strategy TEXT,
                    signal TEXT,
                    confidence REAL,
                    reason_codes TEXT DEFAULT 'NONE',
                    
                    -- Gate decisions
                    gate_allowed INTEGER,
                    gate_reason TEXT,
                    gate_details_json TEXT,
                    
                    -- Action plan
                    intended_action TEXT,
                    sizing_json TEXT,
                    sl_plan REAL,
                    tp_plan REAL,
                    
                    -- Execution result
                    order_id TEXT,
                    execution_status TEXT,
                    execution_error TEXT,
                    fill_price REAL,
                    fill_qty REAL,
                    
                    -- Final outcome
                    final_state_change TEXT,
                    final_position TEXT,

                    -- Event awareness
                    event_blocked INTEGER DEFAULT 0,
                    event_block_reason TEXT,
                    event_block_event_id TEXT,
                    event_block_type TEXT,
                    event_block_details TEXT,

                    -- What produced this row; written by the caller, never inferred
                    provenance TEXT
                , adx REAL, atr_pct REAL, ma_slope REAL, compression_ratio REAL, breakout_pressure REAL, buy_score REAL, sell_score REAL, threshold REAL, active_strategy_count INTEGER, htf_opposed INTEGER, aggressiveness_score REAL, confidence_gate_modifier REAL, size_multiplier REAL, rolling_win_rate REAL, rolling_expectancy REAL, loss_streak INTEGER, ml_score REAL, ml_action TEXT, ml_model_version TEXT, ml_threshold REAL, bot_instance_id TEXT, allocation_mode TEXT, base_size REAL, final_size REAL, final_qty REAL, min_qty REAL, min_notional REAL, submit_attempted INTEGER DEFAULT 0, broker_response TEXT, fill_recorded INTEGER DEFAULT 0, position_opened INTEGER DEFAULT 0, rejection_reason TEXT);
CREATE TABLE deployment_confirmations (
                    id TEXT PRIMARY KEY,
                    confirmation_type TEXT NOT NULL,
                    confirmed_by TEXT NOT NULL,
                    confirmed_at TEXT NOT NULL,
                    source_commit_sha TEXT,
                    release_ref TEXT,
                    evidence_reference TEXT,
                    revoked_at TEXT,
                    revoked_by TEXT
                );
CREATE TABLE deployment_consents (
            consent_id TEXT PRIMARY KEY, user_id TEXT NOT NULL, bot_instance_id TEXT NOT NULL,
            broker_account_id TEXT NOT NULL, risk_level TEXT NOT NULL, risk_profile_version TEXT NOT NULL,
            consent_version TEXT NOT NULL, acknowledged_at TEXT NOT NULL, request_id TEXT NOT NULL,
            preview_json TEXT NOT NULL);
CREATE TABLE dynamic_universe_shadow_diagnostics (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                run_id TEXT,
                cycle_id TEXT,
                bot_instance_id TEXT,
                symbol TEXT NOT NULL,
                rank INTEGER,
                in_live_config INTEGER NOT NULL DEFAULT 0,
                was_evaluated INTEGER NOT NULL DEFAULT 0,
                would_pass_strategy INTEGER NOT NULL DEFAULT 0,
                signal TEXT,
                confidence REAL,
                threshold REAL,
                reason TEXT,
                quote_volume_24h REAL,
                spread_bps REAL,
                exclusion_reasons_json TEXT NOT NULL DEFAULT '[]',
                diagnostics_json TEXT NOT NULL DEFAULT '{}'
            );
CREATE TABLE economic_events (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id      TEXT NOT NULL UNIQUE,
                title         TEXT NOT NULL,
                event_type    TEXT NOT NULL,
                country_currency TEXT NOT NULL,
                impact_level  TEXT NOT NULL,
                scheduled_utc TEXT NOT NULL,
                actual_val    REAL,
                forecast_val  REAL,
                previous_val  REAL,
                source        TEXT NOT NULL DEFAULT 'manual',
                created_at    TEXT NOT NULL,
                updated_at    TEXT NOT NULL
            );
CREATE TABLE email_verifications (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                code_hash TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                attempts INTEGER DEFAULT 0,
                used_at TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id)
            );
CREATE TABLE entry_protection_events (
                id                 INTEGER PRIMARY KEY AUTOINCREMENT,
                ts_ms              INTEGER NOT NULL,
                event_type         TEXT NOT NULL,
                bot_id             TEXT NOT NULL,
                symbol             TEXT NOT NULL,
                side               TEXT NOT NULL,
                state              TEXT,
                submit_state       TEXT,
                client_order_id    TEXT,
                intent_key         TEXT,
                intended_notional  REAL,
                sized_notional     REAL,
                submitted_notional REAL,
                filled_notional    REAL,
                reference_price    REAL,
                protected_exposure REAL,
                max_exposure_limit REAL,
                reason             TEXT,
                cycle_id           TEXT
            );
CREATE TABLE equity_snapshots (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id TEXT NOT NULL,
                    bot_instance_id TEXT,
                    broker_account_id TEXT NOT NULL,
                    broker_id TEXT NOT NULL,
                    timestamp_utc TEXT NOT NULL,
                    wallet_balance REAL,
                    equity REAL,
                    available_balance REAL,
                    unrealized_pnl REAL,
                    margin_used REAL,
                    currency TEXT DEFAULT 'USDT',
                    source TEXT NOT NULL,
                    metadata_json TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
CREATE TABLE event_blackout_windows (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id         INTEGER NOT NULL REFERENCES economic_events(id),
                start_utc        TEXT NOT NULL,
                end_utc          TEXT NOT NULL,
                affected_symbols TEXT,
                is_global        INTEGER NOT NULL DEFAULT 1,
                is_active        INTEGER NOT NULL DEFAULT 1,
                reason           TEXT NOT NULL,
                created_at       TEXT NOT NULL
            );
CREATE TABLE event_market_snapshots (
                id            INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id      TEXT NOT NULL,
                symbol        TEXT NOT NULL,
                exchange      TEXT NOT NULL,
                timestamp_utc TEXT NOT NULL,
                window_label  TEXT NOT NULL,
                price         REAL,
                volume        REAL,
                candle_open   REAL,
                candle_high   REAL,
                candle_low    REAL,
                candle_close  REAL,
                atr           REAL,
                spread        REAL,
                bid_depth     REAL,
                ask_depth     REAL,
                source        TEXT NOT NULL DEFAULT 'binance',
                created_at    TEXT NOT NULL
            );
CREATE TABLE event_news_influence_decisions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                trace_id TEXT,
                symbol TEXT,
                mode TEXT NOT NULL,
                requested_action TEXT NOT NULL,
                applied_action TEXT NOT NULL,
                reason TEXT,
                confidence REAL,
                reliability_score REAL,
                fake_news_risk_score REAL,
                conflict_flag INTEGER NOT NULL DEFAULT 0,
                market_confirmation_status TEXT,
                size_multiplier REAL NOT NULL DEFAULT 1.0,
                confidence_penalty REAL NOT NULL DEFAULT 0.0,
                delay_seconds INTEGER NOT NULL DEFAULT 0,
                cooldown_until TEXT,
                expires_at TEXT,
                source_context_json TEXT NOT NULL DEFAULT '{}',
                created_at TEXT NOT NULL
            );
CREATE TABLE event_news_mode_decisions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                decision_type TEXT NOT NULL,
                from_mode TEXT,
                to_mode TEXT,
                readiness_score REAL NOT NULL DEFAULT 0,
                safety_score REAL NOT NULL DEFAULT 0,
                evidence_json TEXT NOT NULL DEFAULT '{}',
                evaluation_window_start TEXT,
                evaluation_window_end TEXT,
                reason TEXT,
                created_at TEXT NOT NULL
            );
INSERT INTO "event_news_mode_decisions" VALUES(1,'INITIALIZE',NULL,'SHADOW',0.0,0.0,'{"max_allowed_action": "ANNOTATE_ONLY"}','2026-10-14T23:46:08.395895+00:00','2026-10-14T23:46:08.395895+00:00','Initial safe shadow mode','2026-10-14T23:46:08.395895+00:00');
CREATE TABLE event_news_runtime_mode (
                id INTEGER PRIMARY KEY,
                current_mode TEXT NOT NULL,
                previous_mode TEXT,
                max_allowed_action TEXT NOT NULL,
                readiness_score REAL NOT NULL DEFAULT 0,
                safety_status TEXT NOT NULL DEFAULT 'UNKNOWN',
                auto_promotion_enabled INTEGER NOT NULL DEFAULT 1,
                auto_demotion_enabled INTEGER NOT NULL DEFAULT 1,
                reason TEXT,
                failed_criteria_json TEXT NOT NULL DEFAULT '[]',
                passed_criteria_json TEXT NOT NULL DEFAULT '[]',
                promoted_at TEXT,
                demoted_at TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
INSERT INTO "event_news_runtime_mode" VALUES(1,'SHADOW',NULL,'ANNOTATE_ONLY',0.0,'UNKNOWN',1,1,'Initial safe shadow mode','[]','[]',NULL,NULL,'2026-10-14T23:46:08.395895+00:00','2026-10-14T23:46:08.395895+00:00');
CREATE TABLE events (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp_utc TEXT NOT NULL,
                    ts TEXT, -- ✅ Added for consistency
                    run_id TEXT,
                    cycle_id TEXT,
                    symbol TEXT,
                    event_type TEXT NOT NULL,
                    action TEXT,
                    details_json TEXT, trace_id TEXT,
                    FOREIGN KEY(run_id) REFERENCES runs(run_id)
                );
CREATE TABLE execution_attempts (
            execution_attempt_id TEXT PRIMARY KEY,
            decision_id TEXT,
            bot_instance_id TEXT NOT NULL,
            user_id TEXT,
            run_id TEXT,
            cycle_id TEXT,
            execution_mode TEXT,
            broker_environment TEXT,
            provenance TEXT NOT NULL DEFAULT 'PAPER_FORWARD',
            symbol TEXT NOT NULL,
            requested_action TEXT,
            requested_qty REAL,
            requested_notional REAL,
            started_at TEXT NOT NULL,
            completed_at TEXT,
            result TEXT,
            broker_order_id TEXT,
            client_order_id TEXT,
            position_id TEXT,
            primary_reason TEXT,
            error_class TEXT,
            error_detail TEXT
        , executed_qty REAL, avg_fill_price REAL, initial_response_executed_qty REAL, resolved_executed_qty REAL, fill_resolution_source TEXT, fill_resolution_status TEXT, fees REAL, fee_asset TEXT);
CREATE TABLE expert_evaluations (
            expert_evaluation_id INTEGER PRIMARY KEY AUTOINCREMENT,
            threshold_decision_id TEXT,
            decision_id TEXT,
            bot_instance_id TEXT NOT NULL,
            symbol TEXT NOT NULL,
            timeframe TEXT,
            closed_candle_time INTEGER,
            recorded_at TEXT NOT NULL,

            strategy TEXT NOT NULL,
            eligible INTEGER NOT NULL,
            executed INTEGER NOT NULL,
            signal TEXT NOT NULL,
            confidence REAL,
            raw_score REAL,
            weight REAL,
            weighted_contribution REAL,
            reason TEXT
        );
CREATE TABLE external_signal_queue (
                id TEXT PRIMARY KEY,
                source TEXT NOT NULL,
                source_alert_id TEXT NOT NULL,
                bot_id TEXT NOT NULL,
                symbol TEXT NOT NULL,
                side TEXT,
                action TEXT NOT NULL,
                confidence REAL,
                status TEXT NOT NULL,
                available_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                claimed_at TEXT,
                processed_at TEXT,
                result TEXT,
                created_at TEXT NOT NULL
            );
CREATE TABLE fx_reference_ingest_log (
        provider TEXT NOT NULL,
        pair TEXT NOT NULL,
        timeframe TEXT NOT NULL,
        period TEXT NOT NULL,          -- UTC day (1m files) or month (1h files)
        side TEXT NOT NULL,            -- BID | ASK
        status TEXT NOT NULL CHECK (status IN ('FETCHED', 'NO_FILE', 'EMPTY', 'FAILED')),
        rows INTEGER NOT NULL DEFAULT 0,
        reason TEXT,
        recorded_at INTEGER NOT NULL,
        PRIMARY KEY (provider, pair, timeframe, period, side)
    );
CREATE TABLE fx_reference_quotes (
        provider TEXT NOT NULL,
        pair TEXT NOT NULL,
        base_currency TEXT NOT NULL,
        quote_currency TEXT NOT NULL,
        timeframe TEXT NOT NULL,
        open_time INTEGER NOT NULL,
        bid_open REAL, bid_high REAL, bid_low REAL, bid_close REAL,
        ask_open REAL, ask_high REAL, ask_low REAL, ask_close REAL,
        mid_close REAL,
        spread_close REAL,
        volume REAL,
        session TEXT,
        price_kind TEXT NOT NULL DEFAULT 'REFERENCE_MARKET_PRICE',
        source_version TEXT,
        ingested_at INTEGER NOT NULL,
        PRIMARY KEY (provider, pair, timeframe, open_time)
    );
CREATE TABLE fx_reference_repairs (
        repair_id TEXT PRIMARY KEY,
        provider TEXT NOT NULL,
        pair TEXT NOT NULL,
        timeframe TEXT NOT NULL,
        period TEXT NOT NULL,
        old_status TEXT,
        reason TEXT NOT NULL,
        algorithm_version TEXT NOT NULL,
        source_evidence_json TEXT NOT NULL,
        rows_removed INTEGER NOT NULL,
        rows_inserted INTEGER NOT NULL,
        validation_json TEXT,
        recorded_at INTEGER NOT NULL
    );
CREATE TABLE historical_candles (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                
                -- Identifier
                symbol TEXT NOT NULL,
                interval TEXT NOT NULL,
                open_time INTEGER NOT NULL,
                
                -- OHLCV data
                open REAL NOT NULL,
                high REAL NOT NULL,
                low REAL NOT NULL,
                close REAL NOT NULL,
                volume REAL NOT NULL,
                quote_volume REAL,
                trades INTEGER,
                
                -- Multi-asset support
                market_type TEXT NOT NULL DEFAULT 'crypto',
                base_currency TEXT,
                quote_currency TEXT NOT NULL DEFAULT 'USDT',
                
                -- Data provenance
                data_source TEXT NOT NULL,
                data_version TEXT,
                fetched_at TEXT,
                
                UNIQUE(symbol, interval, open_time, data_source, market_type)
            );
CREATE TABLE invariant_violations (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts TEXT NOT NULL,
                    trace_id TEXT,
                    run_id TEXT,
                    bot_instance_id TEXT,
                    symbol TEXT,
                    violation_type TEXT NOT NULL,
                    severity TEXT NOT NULL,
                    details_json TEXT,
                    auto_action_taken TEXT,
                    acknowledged INTEGER DEFAULT 0
                );
CREATE TABLE invoices (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    amount REAL,
                    currency TEXT,
                    status TEXT NOT NULL,           -- paid, open, void, uncollectible
                    period_start TEXT,
                    period_end TEXT,
                    hosted_invoice_url TEXT,
                    created_at TEXT NOT NULL, amount_cents INTEGER, provider_invoice_id TEXT, provider_sub_id TEXT, plan_id TEXT,
                    FOREIGN KEY(user_id) REFERENCES users(id)
                );
CREATE TABLE kyc_audit_log (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    kyc_case_id TEXT,
    event_type TEXT NOT NULL,
    event_data TEXT,
    actor_id TEXT,
    actor_type TEXT DEFAULT 'user',
    ip_address TEXT,
    user_agent TEXT,
    created_at TEXT NOT NULL
);
CREATE TABLE kyc_cases (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL UNIQUE,
    status TEXT NOT NULL DEFAULT 'not_started',
    -- not_started, in_progress, submitted, under_review, approved, rejected, needs_resubmission, expired
    required_steps TEXT DEFAULT '["personal_info","id_document","face_verification"]',
    completed_steps TEXT DEFAULT '[]',
    rejection_reason TEXT,
    rejection_codes TEXT,  -- JSON array of reason codes
    expires_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    submitted_at TEXT,
    approved_at TEXT,
    rejected_at TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE TABLE kyc_documents (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    kyc_case_id TEXT NOT NULL,
    doc_type TEXT NOT NULL,
    issuing_country TEXT,
    doc_number_hash TEXT,
    front_file_ref TEXT,
    back_file_ref TEXT,
    file_content_type TEXT,
    file_size_bytes INTEGER,
    status TEXT NOT NULL DEFAULT 'pending_upload',
    rejection_reason TEXT,
    uploaded_at TEXT,
    reviewed_at TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (kyc_case_id) REFERENCES kyc_cases(id)
);
CREATE TABLE kyc_profiles (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL UNIQUE,
    kyc_case_id TEXT NOT NULL,
    full_legal_name_encrypted TEXT,
    date_of_birth_encrypted TEXT,
    nationality TEXT,
    country_of_residence TEXT,
    address_line1_encrypted TEXT,
    address_city_encrypted TEXT,
    address_state TEXT,
    address_postal_code_encrypted TEXT,
    phone_encrypted TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (kyc_case_id) REFERENCES kyc_cases(id)
);
CREATE TABLE kyc_requirements_config (
    id TEXT PRIMARY KEY,
    action_name TEXT NOT NULL UNIQUE,
    requires_kyc INTEGER NOT NULL DEFAULT 1,
    required_status TEXT DEFAULT 'approved',
    country_exceptions TEXT,
    tier_exceptions TEXT,
    description TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
INSERT INTO "kyc_requirements_config" VALUES('req_live_trading','start_live_trading',1,'approved',NULL,NULL,'Required for live trading with real funds','2026-10-14 23:46:07','2026-10-14 23:46:07');
INSERT INTO "kyc_requirements_config" VALUES('req_signal_provider','become_signal_provider',1,'approved',NULL,NULL,'Required to become a copy trading signal provider','2026-10-14 23:46:07','2026-10-14 23:46:07');
INSERT INTO "kyc_requirements_config" VALUES('req_withdraw','withdraw_funds',1,'approved',NULL,NULL,'Required to withdraw earnings','2026-10-14 23:46:07','2026-10-14 23:46:07');
INSERT INTO "kyc_requirements_config" VALUES('req_api_access','developer_api_access',0,'approved',NULL,NULL,'Optional for API access','2026-10-14 23:46:07','2026-10-14 23:46:07');
INSERT INTO "kyc_requirements_config" VALUES('req_high_limits','increase_limits',1,'approved',NULL,NULL,'Required for higher trading limits','2026-10-14 23:46:07','2026-10-14 23:46:07');
CREATE TABLE kyc_reviews (
    id TEXT PRIMARY KEY,
    kyc_case_id TEXT NOT NULL,
    reviewer_id TEXT,
    reviewer_type TEXT NOT NULL DEFAULT 'system',
    decision TEXT NOT NULL,
    reason_codes TEXT,
    notes_encrypted TEXT,
    created_at TEXT NOT NULL,
    FOREIGN KEY (kyc_case_id) REFERENCES kyc_cases(id)
);
CREATE TABLE kyc_selfie_checks (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    kyc_case_id TEXT NOT NULL,
    provider TEXT DEFAULT 'internal',
    provider_session_id TEXT,
    status TEXT NOT NULL DEFAULT 'not_started',
    confidence_score REAL,
    failure_reason TEXT,
    selfie_file_ref TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    completed_at TEXT,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (kyc_case_id) REFERENCES kyc_cases(id)
);
CREATE TABLE kyc_submissions (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    document_type TEXT,
                    risk_level TEXT,
                    status TEXT DEFAULT 'pending',
                    submitted_at TEXT NOT NULL,
                    reviewed_by TEXT,
                    reviewed_at TEXT,
                    FOREIGN KEY(user_id) REFERENCES users(id)
                );
CREATE TABLE login_attempts (
                id TEXT PRIMARY KEY,
                email TEXT NOT NULL,
                ip TEXT,
                success INTEGER DEFAULT 0,
                attempted_at TEXT NOT NULL
            );
CREATE TABLE manual_news_imports (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                title            TEXT NOT NULL,
                body_snippet     TEXT,
                source_name      TEXT,
                source_url       TEXT,
                published_utc    TEXT NOT NULL,
                affected_symbols TEXT,
                imported_by      TEXT,
                raw_news_item_id INTEGER,
                created_at       TEXT NOT NULL
            );
CREATE TABLE market_candles (
        venue TEXT NOT NULL,
        venue_symbol TEXT NOT NULL,
        canonical_symbol TEXT NOT NULL,
        asset_class TEXT NOT NULL,
        product_type TEXT NOT NULL,
        timeframe TEXT NOT NULL,
        open_time INTEGER NOT NULL,
        close_time INTEGER NOT NULL,
        open REAL NOT NULL,
        high REAL NOT NULL,
        low REAL NOT NULL,
        close REAL NOT NULL,
        volume REAL,
        quote_volume REAL,
        trades INTEGER,
        source TEXT NOT NULL,
        source_version TEXT,
        environment TEXT NOT NULL DEFAULT 'REAL',
        derived_from TEXT,
        ingested_at INTEGER NOT NULL,
        PRIMARY KEY (venue, venue_symbol, product_type, timeframe, open_time, source)
    );
CREATE TABLE market_event_reactions (
                id                       INTEGER PRIMARY KEY AUTOINCREMENT,
                event_id                 TEXT NOT NULL,
                symbol                   TEXT NOT NULL,
                exchange                 TEXT NOT NULL,
                pre_window_start_utc     TEXT,
                event_time_utc           TEXT NOT NULL,
                post_window_end_utc      TEXT,

                price_before_event       REAL,
                price_at_event           REAL,
                price_after_event        REAL,
                price_after_5m           REAL,
                price_after_15m          REAL,
                price_after_30m          REAL,
                price_after_60m          REAL,
                max_move_pct             REAL,
                min_move_pct             REAL,
                net_move_pct             REAL,
                direction_after_event    TEXT,
                continuation_or_reversal TEXT,

                atr_before               REAL,
                atr_after                REAL,
                volatility_expansion_ratio REAL,
                candle_range_before      REAL,
                candle_range_during      REAL,
                realized_vol_before      REAL,
                realized_vol_after       REAL,

                average_volume_before    REAL,
                event_volume             REAL,
                volume_spike_ratio       REAL,
                abnormal_volume_score    REAL,

                spread_before            REAL,
                spread_during            REAL,
                spread_after             REAL,
                spread_widening_ratio    REAL,
                slippage_estimate        REAL,
                order_book_depth_change  REAL,

                reaction_type            TEXT NOT NULL DEFAULT 'NO_REACTION',
                confidence_score         REAL,
                data_quality             TEXT NOT NULL DEFAULT 'COMPLETE',

                created_at               TEXT NOT NULL,
                updated_at               TEXT NOT NULL
            );
CREATE TABLE market_feature_observations (
        venue TEXT NOT NULL,
        venue_symbol TEXT NOT NULL,
        canonical_symbol TEXT NOT NULL,
        asset_class TEXT NOT NULL,
        feature TEXT NOT NULL,
        observed_at INTEGER NOT NULL,
        value REAL,
        value_json TEXT,
        status TEXT NOT NULL CHECK (status IN ('AVAILABLE', 'UNAVAILABLE')),
        unavailable_reason TEXT,
        source TEXT NOT NULL,
        source_version TEXT,
        ingested_at INTEGER NOT NULL,
        CHECK (status = 'AVAILABLE' OR (value IS NULL AND unavailable_reason IS NOT NULL)),
        PRIMARY KEY (venue, venue_symbol, feature, observed_at, source)
    );
CREATE TABLE market_ingest_log (
        venue TEXT NOT NULL,
        venue_symbol TEXT NOT NULL,
        dataset TEXT NOT NULL,
        timeframe TEXT NOT NULL,
        period TEXT NOT NULL,
        status TEXT NOT NULL CHECK (status IN ('FETCHED', 'EMPTY', 'NOT_LISTED', 'UNAVAILABLE', 'FAILED')),
        rows INTEGER NOT NULL DEFAULT 0,
        reason TEXT,
        recorded_at INTEGER NOT NULL,
        PRIMARY KEY (venue, venue_symbol, dataset, timeframe, period)
    );
CREATE TABLE market_snapshots (
            market_snapshot_id TEXT PRIMARY KEY,
            bot_instance_id TEXT,
            symbol TEXT NOT NULL,
            timeframe TEXT NOT NULL,
            closed_candle_open_time INTEGER,
            closed_candle_close_time INTEGER,
            reference_price REAL,
            source TEXT,
            source_environment TEXT,
            provenance TEXT NOT NULL DEFAULT 'PAPER_FORWARD',
            fetched_at TEXT NOT NULL,
            data_hash TEXT,
            higher_timeframe TEXT,
            higher_timeframe_closed_candle_time INTEGER,
            higher_timeframe_aligned INTEGER,
            candle_count INTEGER
        );
CREATE TABLE marketing_events (
                    id TEXT PRIMARY KEY,
                    session_id TEXT NOT NULL,
                    event_type TEXT NOT NULL,
                    page TEXT,
                    metadata_json TEXT,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(session_id) REFERENCES marketing_sessions(id)
                );
CREATE TABLE marketing_sessions (
                    id TEXT PRIMARY KEY,
                    created_at TEXT NOT NULL,
                    ip TEXT,
                    user_agent TEXT,
                    landing_page TEXT,
                    utm_source TEXT,
                    utm_medium TEXT,
                    utm_campaign TEXT,
                    utm_content TEXT,
                    utm_term TEXT,
                    ref_code TEXT,
                    aff_broker TEXT
                );
CREATE TABLE ml_action_runs (
                id TEXT PRIMARY KEY,
                action_key TEXT NOT NULL,
                requested_by_admin_id TEXT,
                requested_by_email TEXT,
                confirmation_phrase TEXT,
                note TEXT,
                status TEXT NOT NULL,
                reason TEXT,
                supported INTEGER NOT NULL DEFAULT 0,
                readiness_snapshot_json TEXT,
                request_payload_json TEXT,
                dataset_path TEXT,
                target_model_version TEXT,
                log_path TEXT,
                command_json TEXT,
                started_at TEXT,
                finished_at TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                result_json TEXT
            );
CREATE TABLE ml_runtime_status (
                scope_key TEXT PRIMARY KEY,
                bot_instance_id TEXT,
                enabled INTEGER NOT NULL DEFAULT 0,
                shadow_mode INTEGER NOT NULL DEFAULT 0,
                loaded INTEGER NOT NULL DEFAULT 0,
                model_version TEXT,
                model_path TEXT,
                metadata_path TEXT,
                encoders_path TEXT,
                threshold REAL,
                hard_block_floor REAL,
                contract_version TEXT,
                schema_hash TEXT,
                last_score_timestamp TEXT,
                last_update_timestamp TEXT NOT NULL,
                load_error TEXT
            );
CREATE TABLE ml_validation_history (
                model_version TEXT PRIMARY KEY,
                training_date TEXT,
                dataset_used TEXT,
                train_rows INTEGER,
                test_rows INTEGER,
                train_auc REAL,
                test_auc REAL,
                validation_method TEXT,
                notes TEXT,
                verdict TEXT NOT NULL,
                deployed_mode TEXT NOT NULL DEFAULT 'not_deployed',
                metadata_path TEXT,
                validation_path TEXT,
                source_payload_json TEXT,
                synced_at TEXT NOT NULL
            );
CREATE TABLE "monthly_snapshots" (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    bot_instance_id TEXT NOT NULL DEFAULT 'default',
                    month_start_date TEXT NOT NULL,
                    start_equity REAL NOT NULL,
                    peak_equity REAL NOT NULL,
                    low_equity REAL NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(bot_instance_id, month_start_date)
                );
CREATE TABLE narrative_effectiveness_scores (
                narrative_type          TEXT PRIMARY KEY,
                sample_count            INTEGER NOT NULL DEFAULT 0,
                avg_impact_score        REAL NOT NULL DEFAULT 0.0,
                avg_price_move_pct      REAL NOT NULL DEFAULT 0.0,
                correct_sentiment_ratio REAL NOT NULL DEFAULT 0.0,
                false_signal_ratio      REAL NOT NULL DEFAULT 0.0,
                avg_effectiveness_score REAL NOT NULL DEFAULT 0.0,
                last_updated            TEXT NOT NULL
            );
CREATE TABLE news_asset_mappings (
                id                     INTEGER PRIMARY KEY AUTOINCREMENT,
                cluster_id             INTEGER NOT NULL REFERENCES news_clusters(id),
                symbol                 TEXT,
                asset                  TEXT,
                mapping_reason         TEXT NOT NULL,
                mapping_confidence     REAL NOT NULL DEFAULT 0.5,
                is_global_market_event INTEGER NOT NULL DEFAULT 0,
                created_at             TEXT NOT NULL
            );
CREATE TABLE news_cluster_items (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                cluster_id       INTEGER NOT NULL REFERENCES news_clusters(id),
                raw_news_item_id INTEGER NOT NULL REFERENCES raw_news_items(id),
                similarity_score REAL NOT NULL DEFAULT 1.0,
                created_at       TEXT NOT NULL,
                UNIQUE(cluster_id, raw_news_item_id)
            );
CREATE TABLE news_clusters (
                id                        INTEGER PRIMARY KEY AUTOINCREMENT,
                canonical_title           TEXT NOT NULL,
                summary                   TEXT,
                first_seen_utc            TEXT NOT NULL,
                last_seen_utc             TEXT NOT NULL,
                source_count              INTEGER NOT NULL DEFAULT 1,
                provider_count            INTEGER NOT NULL DEFAULT 1,
                highest_reliability_score REAL NOT NULL DEFAULT 0.0,
                cluster_confidence        REAL NOT NULL DEFAULT 0.0,
                spam_score                REAL NOT NULL DEFAULT 0.0,
                latency_score             REAL NOT NULL DEFAULT 0.0,
                is_valid_signal           INTEGER NOT NULL DEFAULT 0,
                manipulation_flag         TEXT,
                data_quality_status       TEXT NOT NULL DEFAULT 'LOW_CONFIDENCE',
                is_manipulation_suspect   INTEGER NOT NULL DEFAULT 0,
                manipulation_reason       TEXT,
                created_at                TEXT NOT NULL,
                updated_at                TEXT NOT NULL
            , first_seen_provider TEXT, latency_category TEXT    NOT NULL DEFAULT 'UNKNOWN', confirmation_count INTEGER NOT NULL DEFAULT 0, conflict_flag INTEGER NOT NULL DEFAULT 0, fake_news_risk_score REAL    NOT NULL DEFAULT 0.0, market_confirmation_status TEXT    NOT NULL DEFAULT 'PENDING');
CREATE TABLE news_intelligence_signals (
                id                    INTEGER PRIMARY KEY AUTOINCREMENT,
                cluster_id            INTEGER NOT NULL REFERENCES news_clusters(id),
                symbol                TEXT,
                signal_type           TEXT NOT NULL,
                sentiment_label       TEXT,
                sentiment_score       REAL,
                narrative_type        TEXT,
                severity_level        TEXT NOT NULL DEFAULT 'LOW',
                reliability_score     REAL,
                confidence_score      REAL,
                spam_score            REAL NOT NULL DEFAULT 0.0,
                latency_score         REAL NOT NULL DEFAULT 0.0,
                source_validation_passed INTEGER NOT NULL DEFAULT 0,
                market_validation_passed INTEGER NOT NULL DEFAULT 0,
                is_valid_signal       INTEGER NOT NULL DEFAULT 0,
                manipulation_flag     TEXT,
                data_quality_status   TEXT NOT NULL DEFAULT 'LOW_CONFIDENCE',
                sentiment_accuracy    TEXT,
                validation_status     TEXT NOT NULL DEFAULT 'PENDING_MARKET_VALIDATION',
                should_affect_trading INTEGER NOT NULL DEFAULT 0,
                shadow_only           INTEGER NOT NULL DEFAULT 1,
                validated_at          TEXT,
                suppression_reason    TEXT,
                created_at            TEXT NOT NULL
            , provider_latency_score REAL    NOT NULL DEFAULT 1.0, market_confirmation_status TEXT    NOT NULL DEFAULT 'PENDING', fake_news_risk_score REAL    NOT NULL DEFAULT 0.0, conflict_flag INTEGER NOT NULL DEFAULT 0);
CREATE TABLE news_market_reactions (
                id                         INTEGER PRIMARY KEY AUTOINCREMENT,
                cluster_id                 INTEGER NOT NULL
                                               REFERENCES news_clusters(id),
                symbol                     TEXT NOT NULL,
                event_reaction_id          INTEGER,
                sentiment_score            REAL,
                sentiment_direction        TEXT,
                actual_direction           TEXT,
                sentiment_accuracy         TEXT NOT NULL DEFAULT 'NEUTRAL',
                sentiment_accuracy_score   REAL NOT NULL DEFAULT 0.0,
                impact_score               REAL NOT NULL DEFAULT 0.0,
                max_price_move_pct         REAL,
                volatility_expansion       REAL,
                volume_spike               REAL,
                reaction_type              TEXT NOT NULL DEFAULT 'NO_REACTION',
                reaction_latency_minutes   REAL,
                reaction_latency_category  TEXT NOT NULL DEFAULT 'NO_REACTION',
                signal_effectiveness_score REAL NOT NULL DEFAULT 0.0,
                is_false_signal            INTEGER NOT NULL DEFAULT 0,
                false_signal_reason        TEXT,
                data_quality_score         REAL NOT NULL DEFAULT 0.0,
                reliability_score          REAL NOT NULL DEFAULT 0.0,
                created_at                 TEXT NOT NULL,
                updated_at                 TEXT NOT NULL
            );
CREATE TABLE news_narratives (
                id                   INTEGER PRIMARY KEY AUTOINCREMENT,
                cluster_id           INTEGER NOT NULL REFERENCES news_clusters(id),
                narrative_type       TEXT NOT NULL,
                narrative_confidence REAL NOT NULL,
                severity_level       TEXT NOT NULL DEFAULT 'LOW',
                matched_keywords     TEXT,
                created_at           TEXT NOT NULL,
                updated_at           TEXT
            );
CREATE TABLE news_provider_health (
                id                       INTEGER PRIMARY KEY AUTOINCREMENT,
                source_id                TEXT NOT NULL,
                status                   TEXT NOT NULL DEFAULT 'UNKNOWN',
                last_checked_utc         TEXT NOT NULL,
                last_success_utc         TEXT,
                items_fetched_last_run   INTEGER NOT NULL DEFAULT 0,
                duplicate_count_last_run INTEGER NOT NULL DEFAULT 0,
                error_message            TEXT,
                created_at               TEXT NOT NULL
            );
CREATE TABLE news_sentiment_scores (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                cluster_id       INTEGER NOT NULL REFERENCES news_clusters(id),
                sentiment_score  REAL NOT NULL,
                sentiment_label  TEXT NOT NULL,
                confidence_score REAL NOT NULL,
                model_name       TEXT NOT NULL DEFAULT 'vader',
                model_version    TEXT,
                compound_raw     REAL,
                pos_raw          REAL,
                neg_raw          REAL,
                neu_raw          REAL,
                created_at       TEXT NOT NULL
            );
CREATE TABLE news_sources (
                id                        TEXT PRIMARY KEY,
                source_name               TEXT NOT NULL,
                base_reliability_score    REAL NOT NULL DEFAULT 0.5,
                dynamic_reliability_score REAL NOT NULL DEFAULT 0.5,
                is_trusted                INTEGER NOT NULL DEFAULT 0,
                is_blocked                INTEGER NOT NULL DEFAULT 0,
                created_at                TEXT NOT NULL,
                updated_at                TEXT NOT NULL
            , source_type TEXT    NOT NULL DEFAULT 'API', category TEXT    NOT NULL DEFAULT 'CRYPTO', is_enabled INTEGER NOT NULL DEFAULT 1, fetch_interval_seconds INTEGER NOT NULL DEFAULT 300, rss_url TEXT, last_fetch_utc TEXT, last_success_utc TEXT, last_error TEXT);
INSERT INTO "news_sources" VALUES('reuters.com','Reuters',0.95,0.95,1,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.452412','API','CRYPTO',1,300,NULL,NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('bloomberg.com','Bloomberg',0.95,0.95,1,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.452412','API','CRYPTO',1,300,NULL,NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('ft.com','Financial Times',0.9,0.9,1,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.452412','API','CRYPTO',1,300,NULL,NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('wsj.com','Wall Street Journal',0.9,0.9,1,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.452412','API','CRYPTO',1,300,NULL,NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('apnews.com','AP News',0.9,0.9,1,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.452412','API','CRYPTO',1,300,NULL,NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('coindesk.com','CoinDesk',0.8,0.8,1,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.477470','RSS','CRYPTO',1,300,'https://www.coindesk.com/arc/outboundfeeds/rss/',NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('cointelegraph.com','CoinTelegraph',0.75,0.75,1,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.477470','RSS','CRYPTO',1,300,'https://cointelegraph.com/rss',NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('benzinga.com','Benzinga',0.75,0.75,1,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.452412','API','CRYPTO',1,300,NULL,NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('decrypt.co','Decrypt',0.7,0.7,1,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.477470','RSS','CRYPTO',1,300,'https://decrypt.co/feed',NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('theblock.co','The Block',0.75,0.75,1,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.477470','RSS','CRYPTO',1,300,'https://www.theblock.co/rss.xml',NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('cryptopanic.com','CryptoPanic',0.5,0.5,0,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.452412','API','CRYPTO',1,300,NULL,NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('twitter.com','Twitter/X',0.25,0.25,0,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.452412','API','CRYPTO',1,300,NULL,NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('x.com','Twitter/X',0.25,0.25,0,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.452412','API','CRYPTO',1,300,NULL,NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('reddit.com','Reddit',0.2,0.2,0,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.452412','API','CRYPTO',1,300,NULL,NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('t.me','Telegram',0.15,0.15,0,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.452412','API','CRYPTO',1,300,NULL,NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('unknown','Unknown Source',0.1,0.1,0,0,'2026-10-14T23:46:07.452412','2026-10-14T23:46:07.452412','API','CRYPTO',1,300,NULL,NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('bitcoinmagazine.com','Bitcoin Magazine',0.72,0.72,1,0,'2026-10-14T23:46:07.477470','2026-10-14T23:46:07.477470','RSS','CRYPTO',1,600,'https://bitcoinmagazine.com/.rss/full/',NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('forexlive.com','ForexLive',0.75,0.75,1,0,'2026-10-14T23:46:07.477470','2026-10-14T23:46:07.477470','RSS','MACRO',1,300,'https://www.forexlive.com/feed/news',NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('fxstreet.com','FXStreet',0.7,0.7,1,0,'2026-10-14T23:46:07.477470','2026-10-14T23:46:07.477470','RSS','MACRO',1,300,'https://www.fxstreet.com/rss/news',NULL,NULL,NULL);
INSERT INTO "news_sources" VALUES('investing.com','Investing.com',0.7,0.7,1,0,'2026-10-14T23:46:07.477470','2026-10-14T23:46:07.477470','RSS','MARKET',1,600,'https://www.investing.com/rss/news_301.rss',NULL,NULL,NULL);
CREATE TABLE notification_endpoints (
                    user_id TEXT NOT NULL,
                    channel TEXT NOT NULL,
                    recipient TEXT NOT NULL,
                    status TEXT DEFAULT 'active',
                    verified_at TEXT,
                    last_error TEXT,
                    created_at TEXT NOT NULL,
                    PRIMARY KEY (user_id, channel)
                );
CREATE TABLE notification_jobs (
                    id TEXT PRIMARY KEY,
                    user_id TEXT,
                    channel TEXT NOT NULL,
                    recipient TEXT,
                    template_id TEXT,
                    subject TEXT,
                    body_text TEXT,
                    body_html TEXT,
                    metadata_json TEXT,
                    
                    dedupe_key TEXT,
                    
                    status TEXT DEFAULT 'pending',
                    attempts INTEGER DEFAULT 0,
                    next_retry_at TEXT,
                    
                    processing_token TEXT,
                    processing_started_at TEXT,
                    
                    last_error TEXT,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
CREATE TABLE notification_outbox (
            outbox_id TEXT PRIMARY KEY, event_id TEXT NOT NULL, user_id TEXT NOT NULL, channel TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending', attempts INTEGER NOT NULL DEFAULT 0, next_attempt_at INTEGER NOT NULL,
            last_error TEXT, created_at INTEGER NOT NULL, delivered_at INTEGER, recipient TEXT,
            dedupe_key TEXT NOT NULL UNIQUE);
CREATE TABLE notification_preferences (
                    user_id TEXT NOT NULL,
                    channel TEXT NOT NULL,      -- email, telegram, push, in_app
                    category TEXT NOT NULL,     -- trade, risk, system, marketing
                    is_enabled INTEGER DEFAULT 1,
                    min_severity TEXT DEFAULT 'INFO',
                    updated_at TEXT,
                    PRIMARY KEY (user_id, channel, category)
                );
CREATE TABLE official_strategies_cache (
                strategy_id TEXT PRIMARY KEY,
                name TEXT NOT NULL,
                version TEXT NOT NULL,
                description TEXT,
                strategy_type TEXT,
                market_types_json TEXT,
                indicators_json TEXT,
                params_schema_json TEXT,
                risk_compatibility_json TEXT,
                default_risk_profiles_json TEXT,
                performance_hints_json TEXT,
                updated_at TEXT NOT NULL
            );
CREATE TABLE onboarding_profiles (
                    user_id TEXT PRIMARY KEY,
                    status TEXT NOT NULL,           -- not_started, in_progress, completed, skipped
                    current_step TEXT,
                    data_json TEXT,                 -- answers
                    recommended_defaults TEXT,      -- generated configs
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    completed_at TEXT
                );
CREATE TABLE password_resets (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                code_hash TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                attempts INTEGER DEFAULT 0,
                used_at TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY (user_id) REFERENCES users(id)
            );
CREATE TABLE pending_entries (
                id                  TEXT PRIMARY KEY,
                bot_id              TEXT NOT NULL,
                symbol              TEXT NOT NULL,
                side                TEXT NOT NULL,
                state               TEXT NOT NULL DEFAULT 'PENDING_OPEN',
                submit_state        TEXT NOT NULL DEFAULT 'NOT_SUBMITTED',
                client_order_id     TEXT NOT NULL,
                broker_order_id     TEXT,
                intent_key          TEXT,
                intended_notional   REAL NOT NULL DEFAULT 0.0,
                sized_notional      REAL,
                sized_qty           REAL,
                submitted_notional  REAL,
                submitted_qty       REAL,
                filled_notional     REAL,
                filled_qty          REAL,
                reference_price     REAL,
                submitted_at_ms     INTEGER NOT NULL DEFAULT 0,
                confirmed_at_ms     INTEGER,
                last_reconcile_at_ms INTEGER,
                flat_confirmations  INTEGER NOT NULL DEFAULT 0,
                cycle_id            TEXT,
                error_reason        TEXT,
                created_at          TEXT DEFAULT (datetime('now')),
                updated_at          TEXT DEFAULT (datetime('now')),

                UNIQUE(bot_id, symbol, side)
            );
CREATE TABLE position_events (
            event_id TEXT PRIMARY KEY,
            position_id TEXT NOT NULL,
            bot_instance_id TEXT NOT NULL,
            run_id TEXT,
            cycle_id TEXT,
            decision_id TEXT,
            symbol TEXT NOT NULL,
            event_type TEXT NOT NULL,
            occurred_at TEXT NOT NULL,
            quantity REAL,
            remaining_qty REAL,
            price REAL,
            fee REAL,
            realized_pnl REAL,
            stop_price REAL,
            target_price REAL,
            reason TEXT,
            provenance TEXT NOT NULL DEFAULT 'PAPER_FORWARD',
            detail_json TEXT
        );
CREATE TABLE position_lifecycle_state (
                    bot_instance_id TEXT NOT NULL,
                    symbol TEXT NOT NULL,
                    position_id TEXT,
                    phase TEXT NOT NULL DEFAULT 'SEEKING_TP1',
                    original_stop REAL,
                    current_stop REAL,
                    original_tp1 REAL,
                    original_tp2 REAL,
                    is_break_even INTEGER DEFAULT 0,
                    tp1_hit INTEGER DEFAULT 0,
                    trailing_active INTEGER DEFAULT 0,
                    highest_since_entry REAL,
                    lowest_since_entry REAL,
                    entry_qty_remaining REAL,
                    sl_order_id TEXT,
                    tp_order_id TEXT,
                    exchange_position_active INTEGER,
                    reconciliation_status TEXT,
                    reconciliation_reason TEXT,
                    last_reconciled_at TEXT,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY (bot_instance_id, symbol),
                    FOREIGN KEY(bot_instance_id) REFERENCES bot_instances(id)
                );
CREATE TABLE positions (
            position_id TEXT PRIMARY KEY,
            bot_instance_id TEXT NOT NULL,
            user_id TEXT,
            broker_account_id TEXT,
            run_id TEXT,
            decision_id TEXT,
            execution_attempt_id TEXT,
            symbol TEXT NOT NULL,
            side TEXT NOT NULL,
            execution_mode TEXT,
            broker_environment TEXT,
            provenance TEXT NOT NULL DEFAULT 'PAPER_FORWARD',
            original_qty REAL NOT NULL,
            remaining_qty REAL NOT NULL,
            realized_qty REAL NOT NULL DEFAULT 0,
            entry_price REAL,
            realized_pnl REAL NOT NULL DEFAULT 0,
            fees REAL NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'OPEN',
            opened_at TEXT NOT NULL,
            updated_at TEXT,
            closed_at TEXT,
            close_reason TEXT
        , leverage REAL NOT NULL DEFAULT 1, committed_margin REAL NOT NULL DEFAULT 0, requested_qty REAL, broker_executed_qty REAL, broker_position_mode TEXT, reconciliation_reason TEXT, last_reconciled_at TEXT);
CREATE TABLE pricing_intents (
                    id TEXT PRIMARY KEY,
                    user_id TEXT,
                    plan_id TEXT NOT NULL,
                    session_id TEXT,
                    created_at TEXT NOT NULL
                );
CREATE TABLE protection_state (
                    config_id TEXT PRIMARY KEY,
                    is_protected INTEGER DEFAULT 0,
                    daily_loss_today REAL DEFAULT 0.0,
                    consecutive_losses INTEGER DEFAULT 0,
                    updated_at TEXT,
                    FOREIGN KEY(config_id) REFERENCES user_strategy_configs(id)
                );
CREATE TABLE public_content_blocks (
                    key TEXT NOT NULL,
                    locale TEXT NOT NULL,
                    content_json TEXT NOT NULL,
                    updated_at TEXT,
                    PRIMARY KEY(key, locale)
                );
CREATE TABLE raw_news_items (
                id               INTEGER PRIMARY KEY AUTOINCREMENT,
                provider         TEXT NOT NULL,
                source_name      TEXT,
                source_domain    TEXT,
                source_url       TEXT,
                external_id      TEXT,
                author           TEXT,
                title            TEXT NOT NULL,
                body_snippet     TEXT,
                raw_payload_json TEXT,
                published_utc    TEXT NOT NULL,
                ingested_utc     TEXT NOT NULL,
                latency_seconds  REAL,
                language         TEXT NOT NULL DEFAULT 'en',
                is_duplicate     INTEGER NOT NULL DEFAULT 0,
                created_at       TEXT NOT NULL
            );
CREATE TABLE readiness_approvals (
                    id TEXT PRIMARY KEY,
                    bot_instance_id TEXT NOT NULL,
                    reviewer_admin_id TEXT NOT NULL,
                    approved_at TEXT NOT NULL,
                    revoked_at TEXT,
                    revoked_by TEXT,
                    revocation_reason TEXT,
                    source_commit_sha TEXT,
                    policy_hash TEXT NOT NULL,
                    evidence_snapshot_json TEXT NOT NULL,
                    notes TEXT
                , approval_status TEXT NOT NULL DEFAULT 'APPROVED', reviewer_role TEXT, evidence_snapshot_id TEXT, evidence_hash TEXT, invalidated_at TEXT, invalidation_reason TEXT);
CREATE TABLE readiness_section_confirmations (
            confirmation_id TEXT PRIMARY KEY,
            bot_instance_id TEXT NOT NULL,
            section TEXT NOT NULL,
            confirmed INTEGER NOT NULL DEFAULT 0,
            confirmed_by TEXT,
            confirmed_at TEXT,
            evidence_reference TEXT,
            code_revision TEXT,
            policy_hash TEXT,
            notes TEXT
        );
CREATE TABLE readiness_states (
            bot_instance_id TEXT PRIMARY KEY,
            state TEXT NOT NULL DEFAULT 'NOT_READY',
            policy_hash TEXT,
            evidence_hash TEXT,
            updated_at TEXT NOT NULL,
            updated_by TEXT,
            reason TEXT
        );
CREATE TABLE real_time_news_provider_status (
                id                  INTEGER PRIMARY KEY AUTOINCREMENT,
                provider            TEXT NOT NULL UNIQUE,
                is_enabled          INTEGER NOT NULL DEFAULT 0,
                last_fetch_utc      TEXT,
                last_success_utc    TEXT,
                last_error          TEXT,
                latency_avg_seconds REAL NOT NULL DEFAULT 0.0,
                items_fetched_today INTEGER NOT NULL DEFAULT 0,
                duplicate_rate      REAL NOT NULL DEFAULT 0.0,
                health_status       TEXT NOT NULL DEFAULT 'UNKNOWN',
                created_at          TEXT NOT NULL,
                updated_at          TEXT NOT NULL
            );
INSERT INTO "real_time_news_provider_status" VALUES(1,'cryptopanic',0,NULL,NULL,NULL,0.0,0,0.0,'DISABLED','2026-10-14T23:46:07.497895','2026-10-14T23:46:07.497895');
INSERT INTO "real_time_news_provider_status" VALUES(2,'benzinga',0,NULL,NULL,NULL,0.0,0,0.0,'DISABLED','2026-10-14T23:46:07.497895','2026-10-14T23:46:07.497895');
INSERT INTO "real_time_news_provider_status" VALUES(3,'reuters',0,NULL,NULL,NULL,0.0,0,0.0,'DISABLED','2026-10-14T23:46:07.497895','2026-10-14T23:46:07.497895');
INSERT INTO "real_time_news_provider_status" VALUES(4,'generic',0,NULL,NULL,NULL,0.0,0,0.0,'DISABLED','2026-10-14T23:46:07.497895','2026-10-14T23:46:07.497895');
CREATE TABLE reconciliation_events (
            event_id TEXT PRIMARY KEY,
            bot_instance_id TEXT NOT NULL,
            run_id TEXT,
            cycle_id TEXT,
            symbol TEXT,
            position_id TEXT,
            occurred_at TEXT NOT NULL,
            execution_mode TEXT,
            broker_environment TEXT,
            scope TEXT,
            expected TEXT,
            observed TEXT,
            difference TEXT,
            action TEXT,
            reason TEXT,
            result TEXT,
            provenance TEXT NOT NULL DEFAULT 'PAPER_FORWARD',
            detail_json TEXT
        );
CREATE TABLE revenue_snapshots (
                    date TEXT PRIMARY KEY,
                    subscription_revenue REAL DEFAULT 0,
                    commission_revenue REAL DEFAULT 0,
                    total_revenue REAL DEFAULT 0,
                    created_at TEXT
                );
CREATE TABLE risk_events (
            event_id TEXT PRIMARY KEY,
            bot_instance_id TEXT NOT NULL,
            run_id TEXT,
            cycle_id TEXT,
            decision_id TEXT,
            symbol TEXT,
            event_type TEXT NOT NULL,
            occurred_at TEXT NOT NULL,
            observed_value REAL,
            limit_value REAL,
            action TEXT,
            reason TEXT,
            provenance TEXT NOT NULL DEFAULT 'PAPER_FORWARD',
            detail_json TEXT
        );
CREATE TABLE risk_parameters (
                    config_id TEXT PRIMARY KEY,
                    risk_profile TEXT,
                    portfolio_risk_pct REAL,
                    per_trade_risk_pct REAL,
                    max_margin_usage_pct REAL,
                    max_drawdown_pct REAL,
                    daily_loss_limit_pct REAL,
                    position_sizing_method TEXT,
                    base_position_slots INTEGER,
                    max_position_slots INTEGER,
                    stop_loss_multiplier REAL,
                    take_profit_multiplier REAL,
                    parameters_json TEXT,
                    FOREIGN KEY(config_id) REFERENCES user_strategy_configs(id)
                );
CREATE TABLE run_summary (
                    run_id TEXT PRIMARY KEY,
                    cycles INTEGER NOT NULL DEFAULT 0,
                    trades INTEGER NOT NULL DEFAULT 0,
                    opens INTEGER NOT NULL DEFAULT 0,
                    closes INTEGER NOT NULL DEFAULT 0,
                    errors INTEGER NOT NULL DEFAULT 0,
                    realized_pnl REAL,
                    win_trades INTEGER,
                    loss_trades INTEGER,
                    last_event_at TEXT,
                    updated_at TEXT NOT NULL,
                    FOREIGN KEY(run_id) REFERENCES runs(run_id)
                );
CREATE TABLE runs (
                    run_id TEXT PRIMARY KEY,
                    started_at TEXT NOT NULL,
                    stopped_at TEXT,
                    mode TEXT NOT NULL,
                    interval_seconds INTEGER NOT NULL,
                    max_symbols INTEGER NOT NULL,
                    config_json TEXT,
                    status TEXT
                );
CREATE TABLE runtime_sessions (
            runtime_session_id TEXT PRIMARY KEY,
            started_at TEXT NOT NULL,
            stopped_at TEXT,
            pid INTEGER,
            parent_pid INTEGER,
            python_executable TEXT,
            python_version TEXT,
            working_directory TEXT,
            code_revision TEXT,
            branch TEXT,
            working_tree_dirty INTEGER,
            database_role TEXT,
            database_path TEXT,
            schema_version INTEGER,
            process_execution_mode TEXT,
            environment_name TEXT,
            status TEXT NOT NULL DEFAULT 'RUNNING',
            shutdown_reason TEXT
        );
CREATE TABLE shadow_trade_outcomes (
                id                  TEXT PRIMARY KEY,
                shadow_trade_id     TEXT NOT NULL,
                outcome             TEXT NOT NULL,  -- TP_HIT | SL_HIT | EXPIRED | DATA_MISSING
                exit_time           TEXT,
                exit_price          REAL,
                pnl_abs             REAL,           -- hypothetical gross PnL (1 unit normalized)
                pnl_pct             REAL,           -- PnL as % of entry_price
                pnl_net             REAL,           -- after assumed fee deduction
                mfe                 REAL,           -- max favorable excursion (abs price delta)
                mae                 REAL,           -- max adverse excursion (abs price delta)
                bars_elapsed        INTEGER,
                minutes_elapsed     REAL,
                evaluation_notes    TEXT,           -- JSON: methodology notes, ambiguity flag, etc.
                created_at          TEXT NOT NULL,
                updated_at          TEXT NOT NULL,
                FOREIGN KEY(shadow_trade_id) REFERENCES shadow_trades(id)
            );
CREATE TABLE shadow_trades (
                id                  TEXT PRIMARY KEY,
                bot_instance_id     TEXT NOT NULL,
                trace_id            TEXT NOT NULL,         -- FK to decision_traces.trace_id
                symbol              TEXT NOT NULL,
                side                TEXT,                   -- BUY / SELL
                regime              TEXT,
                strategy            TEXT,
                confidence          REAL,
                threshold           REAL,
                confidence_gap      REAL,                   -- confidence - threshold
                ml_score            REAL,
                ml_action           TEXT,
                gate_reason         TEXT,
                rejection_stage     TEXT NOT NULL,          -- ML_BLOCKED | THRESHOLD_BLOCKED | ...
                rejection_reason    TEXT,
                entry_time          TEXT NOT NULL,          -- ISO timestamp at decision
                entry_price         REAL,                   -- mark price at decision time
                stop_loss           REAL,
                take_profit         REAL,
                expiry_time         TEXT,                   -- ISO timestamp (entry + N bars)
                status              TEXT NOT NULL DEFAULT 'PENDING',
                created_at          TEXT NOT NULL,
                updated_at          TEXT NOT NULL,
                UNIQUE(trace_id)
            );
CREATE TABLE signal_candidates (
                id TEXT PRIMARY KEY,
                asset_class TEXT NOT NULL,
                symbol TEXT NOT NULL,
                side TEXT NOT NULL,
                timeframe TEXT,
                strategy_name TEXT,
                entry_price REAL,
                entry_zone_low REAL,
                entry_zone_high REAL,
                stop_loss REAL,
                take_profit_1 REAL,
                take_profit_2 REAL,
                take_profit_3 REAL,
                risk_reward REAL,
                confidence_score REAL,
                signal_reason TEXT,
                rejection_reason TEXT,
                source TEXT NOT NULL DEFAULT 'internal_signal_engine',
                status TEXT NOT NULL DEFAULT 'CANDIDATE',
                dev_mode INTEGER DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
CREATE TABLE signal_delivery (
                id TEXT PRIMARY KEY,
                signal_id TEXT NOT NULL,
                user_id TEXT NOT NULL,
                delivered_at TEXT,
                viewed_at TEXT,
                saved INTEGER DEFAULT 0,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(signal_id) REFERENCES trading_signals(id)
            );
CREATE TABLE signal_notifications (
                id TEXT PRIMARY KEY,
                user_id TEXT,
                signal_id TEXT,
                symbol TEXT,
                event_type TEXT NOT NULL,
                title TEXT NOT NULL,
                message TEXT NOT NULL,
                channel TEXT DEFAULT 'in_app',
                status TEXT DEFAULT 'PENDING',
                read_at TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
CREATE TABLE signal_operation_locks (
                lock_name TEXT PRIMARY KEY,
                locked_by TEXT,
                locked_at TEXT NOT NULL,
                expires_at TEXT NOT NULL,
                metadata TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
CREATE TABLE signal_outcomes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            strategy TEXT NOT NULL,
            strategy_version TEXT NOT NULL,
            symbol TEXT NOT NULL,
            asset_class TEXT NOT NULL,
            broker_id TEXT NOT NULL,
            account_id TEXT NOT NULL,
            timeframe TEXT NOT NULL,
            confidence REAL NOT NULL,
            outcome INTEGER NOT NULL, -- 1 win / 0 loss
            pnl REAL NOT NULL,
            r_multiple REAL,
            opened_at TEXT,
            closed_at TEXT,
            created_at TEXT NOT NULL
        );
CREATE TABLE signal_pair_metrics (
                symbol TEXT PRIMARY KEY,
                exchange TEXT NOT NULL,
                quote_volume_24h REAL,
                spread_percent REAL,
                bid_price REAL,
                ask_price REAL,
                candle_count INTEGER,
                atr_percent REAL,
                volatility_score REAL,
                liquidity_score REAL,
                spread_score REAL,
                reliability_score REAL,
                is_safe INTEGER DEFAULT 0,
                unsafe_reason TEXT,
                last_updated TEXT NOT NULL
            );
CREATE TABLE signal_pair_universe (
                symbol TEXT PRIMARY KEY,
                exchange TEXT NOT NULL,
                asset_class TEXT NOT NULL DEFAULT 'crypto',
                quote_asset TEXT,
                contract_type TEXT,
                tier TEXT,
                enabled INTEGER DEFAULT 1,
                whitelisted INTEGER DEFAULT 0,
                blacklisted INTEGER DEFAULT 0,
                blacklist_reason TEXT,
                discovered_at TEXT,
                last_seen_at TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
CREATE TABLE signal_performance (
                id TEXT PRIMARY KEY,
                signal_id TEXT NOT NULL,
                asset_class TEXT NOT NULL,
                symbol TEXT NOT NULL,
                side TEXT NOT NULL,
                entry_triggered INTEGER DEFAULT 0,
                tp1_hit INTEGER DEFAULT 0,
                tp2_hit INTEGER DEFAULT 0,
                tp3_hit INTEGER DEFAULT 0,
                sl_hit INTEGER DEFAULT 0,
                expired INTEGER DEFAULT 0,
                cancelled INTEGER DEFAULT 0,
                invalidated INTEGER DEFAULT 0,
                max_favorable_move REAL,
                max_adverse_move REAL,
                result TEXT,
                closed_at TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(signal_id) REFERENCES trading_signals(id)
            );
CREATE TABLE signal_scan_results (
                id TEXT PRIMARY KEY,
                scan_run_id TEXT NOT NULL,
                symbol TEXT NOT NULL,
                was_scanned INTEGER DEFAULT 0,
                was_skipped INTEGER DEFAULT 0,
                skip_reason TEXT,
                candidate_count INTEGER DEFAULT 0,
                accepted_count INTEGER DEFAULT 0,
                rejected_count INTEGER DEFAULT 0,
                published_count INTEGER DEFAULT 0,
                error TEXT,
                created_at TEXT NOT NULL,
                FOREIGN KEY(scan_run_id) REFERENCES signal_scan_runs(id)
            );
CREATE TABLE signal_scan_runs (
                id TEXT PRIMARY KEY,
                scan_type TEXT NOT NULL,
                started_at TEXT NOT NULL,
                ended_at TEXT,
                duration_seconds REAL,
                symbols_discovered INTEGER DEFAULT 0,
                symbols_eligible INTEGER DEFAULT 0,
                symbols_scanned INTEGER DEFAULT 0,
                candidates_created INTEGER DEFAULT 0,
                signals_published INTEGER DEFAULT 0,
                errors TEXT,
                status TEXT NOT NULL,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
CREATE TABLE signal_system_settings (
                key TEXT PRIMARY KEY,
                value TEXT,
                updated_at TEXT NOT NULL
            );
CREATE TABLE strategies (
                    id TEXT PRIMARY KEY,
                    owner_id TEXT,                  -- NULL for official/system strategies
                    visibility TEXT NOT NULL,       -- official, community, private, premium
                    status TEXT NOT NULL,           -- draft, active, deprecated, removed, under_review, rejected
                    name TEXT NOT NULL,
                    description TEXT,
                    market_types JSON,              -- ["crypto", "forex"]
                    timeframes JSON,                -- ["1m", "1h"]
                    tags JSON,                      -- ["trend", "scalping"]
                    entitlement_tier TEXT DEFAULT 'free', -- plan requirement
                    recommended_risk_style TEXT,    -- conservative, aggressive
                    constraints_json TEXT,          -- {"required": ["LEVERAGE"], "min_capital": 1000}
                    metrics_json TEXT,              -- Cached stats: {"win_rate": 65.4, "roi": 12.0}
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
CREATE TABLE strategy_parameters (
                    config_id TEXT PRIMARY KEY,
                    overrides_json TEXT,
                    FOREIGN KEY(config_id) REFERENCES user_strategy_configs(id)
                );
CREATE TABLE strategy_performance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            strategy TEXT NOT NULL,
            strategy_version TEXT NOT NULL,
            symbol TEXT NOT NULL,
            asset_class TEXT NOT NULL,
            broker_id TEXT NOT NULL,
            account_id TEXT NOT NULL,
            timeframe TEXT NOT NULL,
            trades INTEGER NOT NULL DEFAULT 0,
            wins INTEGER NOT NULL DEFAULT 0,
            losses INTEGER NOT NULL DEFAULT 0,
            net_pnl REAL NOT NULL DEFAULT 0,
            gross_pnl REAL NOT NULL DEFAULT 0,
            fees REAL NOT NULL DEFAULT 0,
            avg_slippage REAL NOT NULL DEFAULT 0,
            avg_r REAL NOT NULL DEFAULT 0,
            max_drawdown REAL NOT NULL DEFAULT 0,
            updated_at TEXT NOT NULL
        );
CREATE TABLE strategy_versions (
                    id TEXT PRIMARY KEY,
                    strategy_id TEXT NOT NULL,
                    version_number INTEGER NOT NULL,
                    spec_json TEXT NOT NULL,        -- The DSL execution graph
                    param_schema_json TEXT,         -- Inputs for the user UI
                    changelog TEXT,
                    created_at TEXT NOT NULL,
                    FOREIGN KEY(strategy_id) REFERENCES strategies(id)
                );
CREATE TABLE subscriptions (
                    user_id TEXT PRIMARY KEY,
                    plan_id TEXT NOT NULL,
                    status TEXT NOT NULL,           -- trialing, active, past_due, canceled, incomplete
                    provider_sub_id TEXT,
                    current_period_end TEXT,
                    cancel_at_period_end INTEGER DEFAULT 0,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                , provider TEXT, provider_customer_id TEXT, provider_price_id TEXT, billing_interval TEXT, grace_period_end TEXT, checkout_session_id TEXT, previous_plan_id TEXT, provider_updated_at INTEGER);
CREATE TABLE symbol_state (
                    symbol TEXT PRIMARY KEY,
                    position TEXT NOT NULL,
                    entry_price REAL,
                    last_signal TEXT NOT NULL,
                    last_action TEXT NOT NULL,
                    last_checked_ms INTEGER NOT NULL,
                    adds INTEGER NOT NULL,
                    last_trade_ms INTEGER NOT NULL,
                    pending_open TEXT NOT NULL,
                    entry_qty REAL NOT NULL,
                    last_user_trade_id INTEGER NOT NULL DEFAULT 0,
                    last_stop_ms INTEGER NOT NULL DEFAULT 0,
                    reentry_confirm_signal TEXT NOT NULL DEFAULT 'NONE',
                    reentry_confirm_count INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL
                , lifecycle_phase TEXT DEFAULT 'SEEKING_TP1', lifecycle_current_stop REAL, lifecycle_original_stop REAL, lifecycle_tp1 REAL, lifecycle_tp2 REAL, lifecycle_is_be INTEGER DEFAULT 0, lifecycle_tp1_hit INTEGER DEFAULT 0, lifecycle_trailing INTEGER DEFAULT 0, lifecycle_highest REAL, lifecycle_lowest REAL, lifecycle_qty_remaining REAL, lifecycle_sl_order_id TEXT, lifecycle_tp_order_id TEXT);
CREATE TABLE symbol_universe_promotion_decisions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                created_at TEXT NOT NULL,
                bot_instance_id TEXT NOT NULL,
                decision_type TEXT NOT NULL,
                from_mode TEXT NOT NULL,
                to_mode TEXT NOT NULL,
                status TEXT NOT NULL,
                selected_symbols_json TEXT NOT NULL DEFAULT '[]',
                evidence_summary_json TEXT NOT NULL DEFAULT '{}',
                ranking_run_ids_json TEXT NOT NULL DEFAULT '[]',
                failure_reasons_json TEXT NOT NULL DEFAULT '[]',
                executed INTEGER NOT NULL DEFAULT 0,
                executed_at TEXT,
                audit_event_type TEXT
            );
CREATE TABLE symbol_universe_rankings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ranking_run_id TEXT,
                created_at TEXT NOT NULL,
                bot_instance_id TEXT,
                mode TEXT NOT NULL,
                symbol TEXT NOT NULL,
                rank INTEGER,
                score REAL,
                recommended_action TEXT NOT NULL,
                selected_for_trading INTEGER NOT NULL DEFAULT 0,
                preserved_for_management INTEGER NOT NULL DEFAULT 0,
                quote_volume_24h REAL,
                spread_bps REAL,
                volatility_quality REAL,
                candle_sufficiency INTEGER,
                funding_stability REAL,
                open_interest REAL,
                signal_frequency REAL,
                average_confidence REAL,
                would_pass_count INTEGER,
                recent_performance_score REAL,
                inclusion_reason TEXT,
                exclusion_reason TEXT,
                diagnostics_json TEXT NOT NULL DEFAULT '{}'
            );
CREATE TABLE system_settings (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    description TEXT,
                    updated_at TEXT NOT NULL,
                    updated_by TEXT
                );
CREATE TABLE telegram_link_codes (
                    code TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    expires_at TEXT NOT NULL
                );
CREATE TABLE threshold_decisions (
            threshold_decision_id TEXT PRIMARY KEY,

            bot_instance_id TEXT NOT NULL,
            run_id TEXT,
            cycle_id TEXT,
            decision_id TEXT,
            opportunity_id TEXT,
            market_snapshot_id TEXT,

            symbol TEXT NOT NULL,
            venue TEXT,
            market_type TEXT,
            timeframe TEXT,
            closed_candle_time INTEGER,
            decided_at TEXT NOT NULL,

            threshold_engine_version TEXT NOT NULL,
            threshold_mode TEXT NOT NULL,
            policy_hash TEXT,
            provenance TEXT NOT NULL DEFAULT 'PAPER_FORWARD',

            status TEXT NOT NULL,
            opportunity_confidence REAL,
            base_threshold REAL,

            regime TEXT,
            regime_adjustment REAL,
            volatility_score REAL,
            volatility_adjustment REAL,
            expert_agreement_score REAL,
            agreement_adjustment REAL,
            htf_alignment_score REAL,
            htf_adjustment REAL,
            market_quality_score REAL,
            market_quality_adjustment REAL,

            performance_score REAL,
            performance_adjustment REAL,
            performance_sample_size INTEGER,
            performance_status TEXT,
            distribution_percentile REAL,
            distribution_adjustment REAL,
            distribution_sample_size INTEGER,
            distribution_status TEXT,

            market_threshold REAL,
            calibration_adjustment REAL,
            raw_unclamped_threshold REAL,
            smoothed_threshold REAL,
            rate_limited_threshold REAL,
            final_threshold REAL,

            min_threshold REAL,
            max_threshold REAL,
            previous_threshold REAL,
            smoothing_applied INTEGER NOT NULL DEFAULT 0,
            rate_limit_applied INTEGER NOT NULL DEFAULT 0,
            clamp_applied INTEGER NOT NULL DEFAULT 0,

            passed INTEGER,
            reason TEXT,
            detail TEXT,
            reconciles INTEGER
        );
CREATE TABLE trade_fills (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    run_id TEXT,
                    cycle_id TEXT,
                    trace_id TEXT,
                    symbol TEXT NOT NULL,
                    side TEXT NOT NULL,                 -- LONG/SHORT
                    action TEXT NOT NULL,               -- OPEN/CLOSE
                    qty REAL NOT NULL,
                    price REAL NOT NULL,
                    fee REAL,
                    realized_pnl REAL,                  -- only for CLOSE
                    timestamp_utc TEXT NOT NULL,
                    slippage_pct REAL,
                    entry_price_expected REAL,
                    stop_loss_price REAL,
                    position_id TEXT,
                    r_multiple REAL,
                    market_type TEXT,
                    execution_mode TEXT
                    ,fill_type TEXT
                    ,remaining_qty REAL
                , user_id TEXT, bot_instance_id TEXT, broker_account_id TEXT, quote_currency TEXT DEFAULT 'USDT', base_currency TEXT, order_id TEXT, provenance TEXT, strategy TEXT, strategy_version TEXT, timeframe TEXT, confidence REAL, broker_id TEXT, account_id TEXT, asset_class TEXT, exit_reason TEXT, mfe_pct REAL, mae_pct REAL, exit_regime TEXT, exit_regime_confidence REAL, initiator_type TEXT, trigger_source TEXT, position_phase TEXT, time_in_trade_sec REAL, sl_at_exit REAL, tp_at_exit REAL, market_price_used REAL, price_source TEXT, opposite_signal_detected INTEGER, ensemble_decision TEXT, risk_force_close INTEGER, sync_state_before TEXT, sync_state_after TEXT, close_order_type TEXT, broker_response TEXT, expected_close INTEGER, gross_pnl REAL, total_fees REAL, funding_fees REAL, net_pnl REAL, net_pnl_percent REAL, entry_fee REAL, exit_fee REAL, fees_estimated INTEGER, slippage_estimated INTEGER);
CREATE TABLE trading_cycles (
            cycle_id TEXT PRIMARY KEY,
            run_id TEXT,
            runtime_session_id TEXT,
            bot_instance_id TEXT NOT NULL,
            policy_hash TEXT,
            provenance TEXT NOT NULL DEFAULT 'PAPER_FORWARD',
            started_at TEXT NOT NULL,
            completed_at TEXT,
            symbols_seen INTEGER NOT NULL DEFAULT 0,
            symbols_managed INTEGER NOT NULL DEFAULT 0,
            new_candle_evaluations INTEGER NOT NULL DEFAULT 0,
            no_new_candle_count INTEGER NOT NULL DEFAULT 0,
            no_opportunity_count INTEGER NOT NULL DEFAULT 0,
            quality_rejection_count INTEGER NOT NULL DEFAULT 0,
            risk_rejection_count INTEGER NOT NULL DEFAULT 0,
            execution_rejection_count INTEGER NOT NULL DEFAULT 0,
            approved_count INTEGER NOT NULL DEFAULT 0,
            execution_attempt_count INTEGER NOT NULL DEFAULT 0,
            fill_count INTEGER NOT NULL DEFAULT 0,
            open_count INTEGER NOT NULL DEFAULT 0,
            partial_close_count INTEGER NOT NULL DEFAULT 0,
            close_count INTEGER NOT NULL DEFAULT 0,
            error_count INTEGER NOT NULL DEFAULT 0,
            reason_counts_json TEXT
        );
CREATE TABLE trading_decisions (
            decision_id TEXT PRIMARY KEY,

            runtime_session_id TEXT,
            bot_instance_id TEXT NOT NULL,
            user_id TEXT,
            broker_account_id TEXT,
            run_id TEXT,
            cycle_id TEXT,
            market_snapshot_id TEXT,
            opportunity_id TEXT,
            policy_hash TEXT,

            symbol TEXT NOT NULL,
            market_type TEXT,
            timeframe TEXT,
            closed_candle_open_time INTEGER,
            closed_candle_close_time INTEGER,
            evaluated_at TEXT NOT NULL,

            provenance TEXT NOT NULL DEFAULT 'PAPER_FORWARD',
            evidence_quality TEXT NOT NULL DEFAULT 'COMPLETE',
            execution_mode TEXT,
            broker_environment TEXT,

            regime TEXT,
            regime_confidence REAL,
            component_signals_json TEXT,
            active_strategies_json TEXT,
            supporting_strategies_json TEXT,
            opposing_strategies_json TEXT,
            component_metadata_json TEXT,

            buy_score REAL,
            sell_score REAL,
            consensus_observed REAL,
            consensus_required REAL,
            raw_confidence REAL,

            threshold_base REAL,
            threshold_dynamic REAL,
            threshold_adaptive_modifier REAL,
            threshold_regime_modifier REAL,
            effective_entry_threshold REAL,

            quality_result TEXT,
            quality_reason TEXT,
            hard_veto_result TEXT,
            hard_veto_reason TEXT,
            risk_result TEXT,
            risk_reason TEXT,

            requested_margin REAL,
            approved_margin REAL,
            requested_notional REAL,
            approved_notional REAL,
            quantity REAL,
            leverage REAL,
            risk_amount REAL,
            stop_price REAL,
            target_price REAL,
            stop_distance REAL,
            reward_distance REAL,
            resolved_rr REAL,

            execution_feasibility_result TEXT,
            execution_feasibility_reason TEXT,
            entry_protection_result TEXT,
            entry_protection_reason TEXT,

            execution_attempt_id TEXT,
            order_id TEXT,
            fill_ids_json TEXT,
            position_id TEXT,

            final_action TEXT,
            primary_reason TEXT,
            secondary_reasons_json TEXT,
            legacy_reason TEXT,

            complete INTEGER NOT NULL DEFAULT 0,
            finalized_at TEXT
        , threshold_decision_id TEXT, threshold_status TEXT, threshold_engine_version TEXT, threshold_mode TEXT);
CREATE TABLE trading_signals (
                id TEXT PRIMARY KEY,
                candidate_id TEXT,
                asset_class TEXT NOT NULL,
                symbol TEXT NOT NULL,
                side TEXT NOT NULL,
                timeframe TEXT,
                strategy_name TEXT,
                entry_price REAL NOT NULL,
                entry_zone_low REAL,
                entry_zone_high REAL,
                stop_loss REAL NOT NULL,
                take_profit_1 REAL NOT NULL,
                take_profit_2 REAL,
                take_profit_3 REAL,
                risk_reward REAL NOT NULL,
                confidence_score REAL NOT NULL,
                signal_reason TEXT,
                status TEXT NOT NULL,
                is_published INTEGER DEFAULT 0,
                source TEXT NOT NULL DEFAULT 'internal_signal_engine',
                dev_mode INTEGER DEFAULT 0,
                created_at TEXT NOT NULL,
                published_at TEXT,
                expires_at TEXT NOT NULL,
                invalidated_at TEXT,
                tp1_hit_at TEXT,
                tp2_hit_at TEXT,
                tp3_hit_at TEXT,
                sl_hit_at TEXT,
                cancelled_at TEXT,
                updated_at TEXT NOT NULL,
                FOREIGN KEY(candidate_id) REFERENCES signal_candidates(id)
            );
CREATE TABLE tradingview_alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                webhook_id TEXT,
                bot_id TEXT,
                alert_id TEXT,
                symbol_raw TEXT,
                symbol_normalized TEXT,
                action TEXT,
                side TEXT,
                timeframe TEXT,
                strategy_name TEXT,
                price REAL,
                payload_json TEXT NOT NULL DEFAULT '{}',
                received_at TEXT NOT NULL,
                alert_timestamp TEXT,
                status TEXT NOT NULL,
                reject_reason TEXT,
                idempotency_key TEXT,
                source_ip TEXT,
                signature_valid INTEGER,
                created_at TEXT NOT NULL
            );
CREATE TABLE tradingview_processor_heartbeat (
                bot_instance_id TEXT PRIMARY KEY,
                processor_enabled INTEGER NOT NULL DEFAULT 0,
                env_gate_reason TEXT,
                last_started_at TEXT,
                last_finished_at TEXT,
                last_processed_count INTEGER NOT NULL DEFAULT 0,
                last_rejected_count INTEGER NOT NULL DEFAULT 0,
                last_failed_count INTEGER NOT NULL DEFAULT 0,
                last_skipped_count INTEGER NOT NULL DEFAULT 0,
                last_skipped_reason TEXT,
                last_result_json TEXT,
                last_error TEXT,
                updated_at TEXT NOT NULL
            );
CREATE TABLE tradingview_safety_lockouts (
                bot_instance_id TEXT PRIMARY KEY,
                is_locked INTEGER NOT NULL DEFAULT 0,
                reason TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            );
CREATE TABLE tradingview_signal_decisions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                alert_id INTEGER NOT NULL,
                bot_id TEXT,
                symbol TEXT,
                action TEXT,
                mode TEXT NOT NULL,
                normalized_signal_json TEXT NOT NULL DEFAULT '{}',
                event_filter_result TEXT,
                policy_result TEXT,
                sizing_result TEXT,
                execution_result TEXT,
                decision_trace_id TEXT,
                final_status TEXT NOT NULL,
                final_reason TEXT NOT NULL,
                queue_id TEXT,
                created_at TEXT NOT NULL
            );
CREATE TABLE tradingview_webhooks (
                id TEXT PRIMARY KEY,
                bot_id TEXT NOT NULL,
                name TEXT NOT NULL,
                token_hash TEXT NOT NULL,
                secret_hash TEXT,
                mode TEXT NOT NULL DEFAULT 'ADVISORY_ONLY',
                is_enabled INTEGER NOT NULL DEFAULT 1,
                allowed_symbols_json TEXT,
                allowed_actions_json TEXT NOT NULL DEFAULT '["BUY","SELL"]',
                max_alert_age_seconds INTEGER NOT NULL DEFAULT 300,
                rate_limit_per_minute INTEGER NOT NULL DEFAULT 30,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                last_used_at TEXT
            );
CREATE TABLE universe_manifests (
        manifest_id TEXT PRIMARY KEY,
        manifest_hash TEXT NOT NULL UNIQUE,
        role TEXT NOT NULL CHECK (role IN ('RESEARCH_UNIVERSE', 'TRAINING_UNIVERSE',
                                           'CERTIFICATION_UNIVERSE', 'EXECUTION_UNIVERSE')),
        asset_class TEXT NOT NULL,
        venue TEXT NOT NULL,
        instruments_json TEXT NOT NULL,
        selection_json TEXT NOT NULL,
        created_at INTEGER NOT NULL
    );
CREATE TABLE universe_members (
    snapshot_id       TEXT NOT NULL,
    symbol            TEXT NOT NULL,
    rank              INTEGER,
    canonical_id      TEXT,
    underlying        TEXT,
    quote_volume_24h  REAL,
    spread_bps        REAL,
    trade_count_24h   INTEGER,
    last_price        REAL,
    selection_reason  TEXT,
    PRIMARY KEY (snapshot_id, symbol)
);
CREATE TABLE universe_mode_migrations (
    bot_instance_id        TEXT PRIMARY KEY,
    migrated_at            TEXT NOT NULL,
    previous_mode          TEXT,
    new_mode               TEXT NOT NULL,
    previous_symbols_json  TEXT,
    reason                 TEXT NOT NULL
);
CREATE TABLE universe_snapshots (
    snapshot_id              TEXT PRIMARY KEY,
    bot_instance_id          TEXT,
    broker_account_id        TEXT,
    run_id                   TEXT,
    runtime_session_id       TEXT,
    venue                    TEXT,
    universe_mode            TEXT NOT NULL,
    generated_at             TEXT NOT NULL,
    discovered_count         INTEGER NOT NULL DEFAULT 0,
    eligible_count           INTEGER NOT NULL DEFAULT 0,
    ranked_count             INTEGER NOT NULL DEFAULT 0,
    active_count             INTEGER NOT NULL DEFAULT 0,
    excluded_count           INTEGER NOT NULL DEFAULT 0,
    managed_count            INTEGER NOT NULL DEFAULT 0,
    excluded_by_reason_json  TEXT,
    excluded_json            TEXT,
    active_symbols_json      TEXT,
    managed_symbols_json     TEXT,
    open_symbols_json        TEXT,
    stale                    INTEGER NOT NULL DEFAULT 0,
    error                    TEXT,
    capabilities_json        TEXT,
    config_json              TEXT,
    metadata_age_seconds     REAL,
    stats_age_seconds        REAL,
    request_weight_used      INTEGER,
    request_weight_limit     INTEGER
);
CREATE TABLE user_events (
            event_id TEXT PRIMARY KEY, event_type TEXT NOT NULL, at INTEGER NOT NULL, user_id TEXT NOT NULL,
            bot_id TEXT, broker_account_id TEXT, environment TEXT, payload_json TEXT NOT NULL, created_at TEXT NOT NULL);
CREATE TABLE user_signal_preferences (
                id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                crypto_enabled INTEGER DEFAULT 1,
                forex_enabled INTEGER DEFAULT 0,
                preferred_symbols TEXT,
                minimum_confidence REAL DEFAULT 70,
                notifications_enabled INTEGER DEFAULT 1,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            , favorite_symbols TEXT, hidden_symbols TEXT, majors_only INTEGER DEFAULT 0, risk_style TEXT DEFAULT 'balanced', notify_new_signal INTEGER DEFAULT 1, notify_signal_invalidated INTEGER DEFAULT 1, notify_tp1_hit INTEGER DEFAULT 0, notify_tp2_hit INTEGER DEFAULT 1, notify_tp3_hit INTEGER DEFAULT 1, notify_sl_hit INTEGER DEFAULT 1, notify_entry_window_expiring INTEGER DEFAULT 1);
CREATE TABLE user_strategies (
                    user_id TEXT NOT NULL,
                    strategy_id TEXT NOT NULL,
                    is_favorite INTEGER DEFAULT 0,
                    last_used_at TEXT,
                    created_at TEXT NOT NULL,
                    PRIMARY KEY(user_id, strategy_id),
                    FOREIGN KEY(strategy_id) REFERENCES strategies(id)
                );
CREATE TABLE user_strategy_configs (
                    id TEXT PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    broker_account_id TEXT NOT NULL,
                    strategy_id TEXT NOT NULL,
                    name TEXT NOT NULL,
                    status TEXT NOT NULL,
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    activated_at TEXT
                , symbols_json TEXT, timeframes_json TEXT, allocation_type TEXT DEFAULT 'percent_balance', allocation_value REAL DEFAULT 1.0);
CREATE TABLE users (
                    id TEXT PRIMARY KEY,
                    email TEXT UNIQUE NOT NULL,
                    hashed_password TEXT NOT NULL,
                    full_name TEXT,
                    is_active INTEGER DEFAULT 1,
                    is_superuser INTEGER DEFAULT 0,
                    status TEXT DEFAULT 'pending_verification',
                    created_at TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                , last_login_at TEXT, is_verified INTEGER DEFAULT 0, terms_accepted_at TEXT, risk_disclaimer_accepted_at TEXT, locale TEXT, country TEXT, timezone TEXT, marketing_session_id TEXT, selected_plan_id TEXT, total_trades INTEGER DEFAULT 0, total_commission REAL DEFAULT 0, role TEXT DEFAULT 'user', totp_secret TEXT, is_2fa_enabled BOOLEAN DEFAULT 0, name TEXT);
CREATE TABLE venue_instruments (
        venue TEXT NOT NULL,
        environment TEXT NOT NULL,
        venue_symbol TEXT NOT NULL,
        asset_class TEXT NOT NULL,
        product_type TEXT NOT NULL,
        canonical_symbol TEXT NOT NULL,
        status TEXT,
        api_tradable INTEGER NOT NULL DEFAULT 0,
        payload_json TEXT NOT NULL,
        first_seen_ms INTEGER NOT NULL,
        last_seen_ms INTEGER NOT NULL,
        delisted_at_ms INTEGER, metadata_hash TEXT, metadata_changed_ms INTEGER,
        PRIMARY KEY (venue, environment, venue_symbol)
    );
CREATE TABLE "weekly_snapshots" (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    bot_instance_id TEXT NOT NULL DEFAULT 'default',
                    week_start_date TEXT NOT NULL,
                    start_equity REAL NOT NULL,
                    peak_equity REAL NOT NULL,
                    low_equity REAL NOT NULL,
                    updated_at TEXT NOT NULL,
                    UNIQUE(bot_instance_id, week_start_date)
                );
CREATE INDEX idx_events_run ON events(run_id);
CREATE INDEX idx_events_time ON events(timestamp_utc);
CREATE INDEX idx_events_symbol ON events(symbol);
CREATE INDEX idx_fills_user_time ON trade_fills(user_id, timestamp_utc);
CREATE INDEX idx_fills_bot_time ON trade_fills(bot_instance_id, timestamp_utc);
CREATE INDEX idx_fills_broker_time ON trade_fills(broker_account_id, timestamp_utc);
CREATE INDEX idx_fills_symbol ON trade_fills(symbol, timestamp_utc);
CREATE INDEX idx_equity_user_time ON equity_snapshots(user_id, timestamp_utc);
CREATE INDEX idx_equity_bot_time ON equity_snapshots(bot_instance_id, timestamp_utc);
CREATE INDEX idx_equity_broker_time ON equity_snapshots(broker_account_id, timestamp_utc);
CREATE INDEX idx_transfers_broker_time ON broker_transfers_cache(broker_account_id, ts_utc);
CREATE INDEX idx_transfers_user_time ON broker_transfers_cache(user_id, ts_utc);
CREATE INDEX idx_bot_system_events_bot_time ON bot_system_events(bot_instance_id, created_at DESC);
CREATE INDEX idx_bot_system_events_reason ON bot_system_events(reason_code, created_at DESC);
CREATE INDEX idx_invariant_violations_bot_ts ON invariant_violations(bot_instance_id, ts);
CREATE INDEX idx_invariant_violations_run_ts ON invariant_violations(run_id, ts);
CREATE INDEX idx_analytics_cache_user ON analytics_cache(user_id);
CREATE INDEX idx_notify_jobs_status ON notification_jobs(status, next_retry_at);
CREATE INDEX idx_notify_jobs_dedupe ON notification_jobs(dedupe_key);
CREATE UNIQUE INDEX idx_tv_alert_webhook_alert ON tradingview_alerts(webhook_id, alert_id);
CREATE UNIQUE INDEX idx_tv_alert_idempotency ON tradingview_alerts(idempotency_key) WHERE idempotency_key IS NOT NULL;
CREATE INDEX idx_tv_alert_bot_received ON tradingview_alerts(bot_id, received_at);
CREATE INDEX idx_tv_alert_symbol_received ON tradingview_alerts(symbol_normalized, received_at);
CREATE INDEX idx_tv_alert_status ON tradingview_alerts(status);
CREATE INDEX idx_tv_decisions_created ON tradingview_signal_decisions(created_at);
CREATE UNIQUE INDEX idx_external_signal_source_alert ON external_signal_queue(source, source_alert_id);
CREATE INDEX idx_external_signal_status ON external_signal_queue(status);
CREATE INDEX idx_external_signal_bot_created ON external_signal_queue(bot_id, created_at);
CREATE INDEX idx_external_signal_symbol_created ON external_signal_queue(symbol, created_at);
CREATE INDEX idx_signal_candidates_symbol ON signal_candidates(symbol);
CREATE INDEX idx_signal_candidates_status ON signal_candidates(status);
CREATE INDEX idx_signal_candidates_created_at ON signal_candidates(created_at);
CREATE INDEX idx_signal_candidates_asset_class ON signal_candidates(asset_class);
CREATE INDEX idx_trading_signals_status ON trading_signals(status);
CREATE INDEX idx_trading_signals_symbol ON trading_signals(symbol);
CREATE INDEX idx_trading_signals_asset_class ON trading_signals(asset_class);
CREATE INDEX idx_trading_signals_is_published ON trading_signals(is_published);
CREATE INDEX idx_trading_signals_expires_at ON trading_signals(expires_at);
CREATE INDEX idx_trading_signals_published_at ON trading_signals(published_at);
CREATE INDEX idx_trading_signals_dev_mode ON trading_signals(dev_mode);
CREATE INDEX idx_signal_performance_signal_id ON signal_performance(signal_id);
CREATE INDEX idx_signal_performance_symbol ON signal_performance(symbol);
CREATE INDEX idx_signal_performance_result ON signal_performance(result);
CREATE INDEX idx_signal_performance_created_at ON signal_performance(created_at);
CREATE INDEX idx_signal_delivery_signal_id ON signal_delivery(signal_id);
CREATE INDEX idx_signal_delivery_user_id ON signal_delivery(user_id);
CREATE INDEX idx_signal_delivery_saved ON signal_delivery(saved);
CREATE INDEX idx_signal_delivery_viewed_at ON signal_delivery(viewed_at);
CREATE INDEX idx_user_signal_preferences_user_id ON user_signal_preferences(user_id);
CREATE INDEX idx_signal_notifications_user_id ON signal_notifications(user_id);
CREATE INDEX idx_signal_notifications_signal_id ON signal_notifications(signal_id);
CREATE INDEX idx_signal_notifications_event_type ON signal_notifications(event_type);
CREATE INDEX idx_signal_notifications_status ON signal_notifications(status);
CREATE INDEX idx_signal_notifications_created_at ON signal_notifications(created_at);
CREATE INDEX idx_signal_notifications_read_at ON signal_notifications(read_at);
CREATE INDEX idx_signal_pair_universe_exchange ON signal_pair_universe(exchange);
CREATE INDEX idx_signal_pair_universe_asset_class ON signal_pair_universe(asset_class);
CREATE INDEX idx_signal_pair_universe_quote_asset ON signal_pair_universe(quote_asset);
CREATE INDEX idx_signal_pair_universe_contract_type ON signal_pair_universe(contract_type);
CREATE INDEX idx_signal_pair_universe_tier ON signal_pair_universe(tier);
CREATE INDEX idx_signal_pair_universe_enabled ON signal_pair_universe(enabled);
CREATE INDEX idx_signal_pair_universe_whitelisted ON signal_pair_universe(whitelisted);
CREATE INDEX idx_signal_pair_universe_blacklisted ON signal_pair_universe(blacklisted);
CREATE INDEX idx_signal_pair_universe_last_seen_at ON signal_pair_universe(last_seen_at);
CREATE INDEX idx_signal_pair_metrics_exchange ON signal_pair_metrics(exchange);
CREATE INDEX idx_signal_pair_metrics_quote_volume_24h ON signal_pair_metrics(quote_volume_24h);
CREATE INDEX idx_signal_pair_metrics_spread_percent ON signal_pair_metrics(spread_percent);
CREATE INDEX idx_signal_pair_metrics_is_safe ON signal_pair_metrics(is_safe);
CREATE INDEX idx_signal_pair_metrics_last_updated ON signal_pair_metrics(last_updated);
CREATE INDEX idx_signal_scan_runs_scan_type ON signal_scan_runs(scan_type);
CREATE INDEX idx_signal_scan_runs_status ON signal_scan_runs(status);
CREATE INDEX idx_signal_scan_runs_started_at ON signal_scan_runs(started_at);
CREATE INDEX idx_signal_scan_runs_ended_at ON signal_scan_runs(ended_at);
CREATE INDEX idx_signal_scan_results_scan_run_id ON signal_scan_results(scan_run_id);
CREATE INDEX idx_signal_scan_results_symbol ON signal_scan_results(symbol);
CREATE INDEX idx_signal_scan_results_was_scanned ON signal_scan_results(was_scanned);
CREATE INDEX idx_signal_scan_results_was_skipped ON signal_scan_results(was_skipped);
CREATE INDEX idx_signal_scan_results_skip_reason ON signal_scan_results(skip_reason);
CREATE INDEX idx_signal_scan_results_created_at ON signal_scan_results(created_at);
CREATE INDEX idx_signal_operation_locks_expires_at ON signal_operation_locks(expires_at);
CREATE INDEX idx_trade_fills_provenance ON trade_fills(provenance);
CREATE INDEX idx_equity_snapshots_time ON equity_snapshots(timestamp_utc);
CREATE INDEX idx_trade_fills_bot_symbol_time ON trade_fills(bot_instance_id, symbol, timestamp_utc);
CREATE INDEX idx_trade_fills_bot_action_time ON trade_fills(bot_instance_id, action, timestamp_utc);
CREATE INDEX idx_trade_fills_decision_trace ON trade_fills(trace_id);
CREATE INDEX idx_admin_sessions_admin_id ON admin_sessions(admin_id);
CREATE INDEX idx_admin_sessions_refresh_hash ON admin_sessions(refresh_token_hash);
CREATE INDEX idx_email_verifications_user_id ON email_verifications(user_id);
CREATE INDEX idx_auth_sessions_user_id ON auth_sessions(user_id);
CREATE INDEX idx_auth_sessions_refresh_hash ON auth_sessions(refresh_token_hash);
CREATE INDEX idx_password_resets_user_id ON password_resets(user_id);
CREATE INDEX idx_login_attempts_email ON login_attempts(email);
CREATE INDEX idx_login_attempts_time ON login_attempts(attempted_at);
CREATE INDEX idx_auth_audit_event_type ON auth_audit_log(event_type);
CREATE INDEX idx_auth_audit_user_id ON auth_audit_log(user_id);
CREATE INDEX idx_auth_audit_created_at ON auth_audit_log(created_at);
CREATE INDEX idx_broker_accounts_user_id ON broker_accounts(user_id);
CREATE INDEX idx_broker_audit_account_id ON broker_audit_log(broker_account_id);
CREATE INDEX idx_invoices_user_id ON invoices(user_id);
CREATE INDEX idx_subscriptions_provider_sub ON subscriptions(provider_sub_id);
CREATE INDEX idx_subscriptions_provider_customer ON subscriptions(provider_customer_id);
CREATE INDEX idx_pricing_intents_session ON pricing_intents(session_id);
CREATE INDEX idx_billing_customers_provider_id ON billing_customers(provider_customer_id);
CREATE UNIQUE INDEX idx_billing_events_provider_event ON billing_events(provider, event_id) WHERE event_id IS NOT NULL;
CREATE INDEX idx_strategies_owner_id ON strategies(owner_id);
CREATE INDEX idx_strategies_visibility ON strategies(visibility);
CREATE INDEX idx_strategy_versions_strategy_id ON strategy_versions(strategy_id);
CREATE INDEX idx_user_strategy_configs_user_id ON user_strategy_configs(user_id);
CREATE INDEX idx_user_strategy_configs_broker_account ON user_strategy_configs(broker_account_id);
CREATE INDEX idx_user_strategy_configs_status ON user_strategy_configs(status);
CREATE INDEX idx_decision_logs_config_id ON decision_logs(config_id);
CREATE INDEX idx_decision_logs_created_at ON decision_logs(created_at);
CREATE INDEX idx_bot_instances_user_id ON bot_instances(user_id);
CREATE INDEX idx_bot_instances_status ON bot_instances(status);
CREATE INDEX idx_bot_instances_broker_account ON bot_instances(broker_account_id);
CREATE INDEX idx_dcv_bot_time ON daily_close_validation_reports(bot_instance_id, validated_at);
CREATE INDEX idx_bot_instances_deploy_request ON bot_instances(deploy_request_id);
CREATE INDEX idx_deployment_consents_bot ON deployment_consents(bot_instance_id);
CREATE INDEX idx_account_equity_snapshots_account_time ON account_equity_snapshots(broker_account_id, observed_at);
CREATE INDEX idx_user_events_user_at ON user_events(user_id, at);
CREATE INDEX idx_user_events_bot_at ON user_events(bot_id, at);
CREATE INDEX idx_notification_outbox_due ON notification_outbox(status, next_attempt_at);
CREATE INDEX idx_backtest_runs_user_created ON backtest_runs(user_id, created_at);
CREATE INDEX idx_backtest_runs_status ON backtest_runs(status);
CREATE INDEX idx_backtest_runs_strategy ON backtest_runs(strategy_id);
CREATE INDEX idx_backtest_jobs_status ON backtest_jobs(status);
CREATE INDEX idx_backtest_jobs_priority ON backtest_jobs(priority, created_at);
CREATE INDEX idx_backtest_jobs_run_id ON backtest_jobs(run_id);
CREATE INDEX idx_backtest_fills_run_id ON backtest_fills(run_id);
CREATE INDEX idx_backtest_fills_symbol ON backtest_fills(symbol);
CREATE INDEX idx_backtest_fills_timestamp ON backtest_fills(timestamp_utc);
CREATE INDEX idx_backtest_equity_run_id ON backtest_equity_curve(run_id);
CREATE INDEX idx_backtest_equity_timestamp ON backtest_equity_curve(timestamp_utc);
CREATE INDEX idx_backtest_decision_logs_run_id ON backtest_decision_logs(run_id);
CREATE INDEX idx_backtest_decision_logs_symbol ON backtest_decision_logs(symbol);
CREATE INDEX idx_historical_candles_symbol_interval ON historical_candles(symbol, interval, open_time);
CREATE INDEX idx_historical_candles_market_type ON historical_candles(market_type, symbol);
CREATE INDEX idx_backtest_performance_run_id ON backtest_performance(run_id);
CREATE INDEX idx_pe_bot_symbol ON pending_entries(bot_id, symbol);
CREATE INDEX idx_epe_bot_symbol_ts ON entry_protection_events(bot_id, symbol, ts_ms);
CREATE INDEX idx_epe_event_ts ON entry_protection_events(event_type, ts_ms);
CREATE INDEX idx_epe_client_ts ON entry_protection_events(client_order_id, ts_ms);
CREATE INDEX idx_trade_fills_action_time ON trade_fills(action, timestamp_utc);
CREATE INDEX idx_trade_fills_position_action ON trade_fills(position_id, action, timestamp_utc);
CREATE INDEX idx_trade_fills_run_cycle_symbol_action ON trade_fills(run_id, cycle_id, symbol, action);
CREATE INDEX idx_decision_traces_run_cycle_symbol ON decision_traces(run_id, cycle_id, symbol);
CREATE INDEX idx_decision_traces_ts ON decision_traces(ts);
CREATE INDEX idx_decision_traces_ml_action ON decision_traces(ml_action, ts);
CREATE INDEX idx_ml_validation_history_training_date ON ml_validation_history(training_date DESC);
CREATE INDEX idx_ml_action_runs_action_created ON ml_action_runs(action_key, created_at DESC);
CREATE INDEX idx_ml_runtime_status_updated ON ml_runtime_status(last_update_timestamp DESC);
CREATE INDEX idx_ml_action_runs_status_created ON ml_action_runs(status, created_at DESC);
CREATE INDEX idx_backtest_fills_run_time ON backtest_fills(run_id, timestamp_utc);
CREATE INDEX idx_backtest_equity_run_time ON backtest_equity_curve(run_id, timestamp_utc);
CREATE INDEX idx_pls_bot_symbol ON position_lifecycle_state(bot_instance_id, symbol);
CREATE INDEX idx_pls_position_id ON position_lifecycle_state(position_id);
CREATE TRIGGER trg_preserve_lifecycle_protection_ids
            AFTER UPDATE OF sl_order_id, tp_order_id ON position_lifecycle_state
            WHEN OLD.sl_order_id IS NOT NULL
             AND OLD.tp_order_id IS NOT NULL
             AND (NEW.sl_order_id IS NULL OR NEW.tp_order_id IS NULL)
            BEGIN
                UPDATE position_lifecycle_state
                   SET sl_order_id = COALESCE(NEW.sl_order_id, OLD.sl_order_id),
                       tp_order_id = COALESCE(NEW.tp_order_id, OLD.tp_order_id),
                       reconciliation_status = CASE
                           WHEN OLD.reconciliation_status = 'PROTECTED' THEN OLD.reconciliation_status
                           ELSE NEW.reconciliation_status
                       END,
                       reconciliation_reason = CASE
                           WHEN OLD.reconciliation_status = 'PROTECTED' THEN OLD.reconciliation_reason
                           ELSE NEW.reconciliation_reason
                       END,
                       last_reconciled_at = COALESCE(NEW.last_reconciled_at, OLD.last_reconciled_at)
                 WHERE bot_instance_id = NEW.bot_instance_id
                   AND symbol = NEW.symbol;
            END;
CREATE INDEX idx_brcred_v2_account ON broker_credentials_v2(account_id);
CREATE INDEX idx_brcred_v2_account_status ON broker_credentials_v2(account_id, status);
CREATE INDEX idx_events_trace_id ON events(trace_id) WHERE trace_id IS NOT NULL;
CREATE INDEX idx_bot_instances_broker_health ON bot_instances(status, broker_health_status);
CREATE INDEX idx_shadow_trades_status ON shadow_trades(status);
CREATE INDEX idx_shadow_trades_trace ON shadow_trades(trace_id);
CREATE INDEX idx_shadow_trades_bot ON shadow_trades(bot_instance_id, created_at);
CREATE INDEX idx_shadow_trades_stage ON shadow_trades(rejection_stage, created_at);
CREATE UNIQUE INDEX idx_shadow_outcomes_shadow_id ON shadow_trade_outcomes(shadow_trade_id);
CREATE INDEX idx_shadow_outcomes_outcome ON shadow_trade_outcomes(outcome);
CREATE INDEX idx_eco_events_scheduled ON economic_events(scheduled_utc);
CREATE INDEX idx_eco_events_impact ON economic_events(impact_level, scheduled_utc);
CREATE INDEX idx_ebw_active_range ON event_blackout_windows(is_active, start_utc, end_utc);
CREATE INDEX idx_ebw_event_id ON event_blackout_windows(event_id);
CREATE UNIQUE INDEX idx_ebw_event_range_unique ON event_blackout_windows(event_id, start_utc, end_utc);
CREATE INDEX idx_ems_event_symbol ON event_market_snapshots(event_id, symbol);
CREATE INDEX idx_ems_timestamp ON event_market_snapshots(timestamp_utc);
CREATE INDEX idx_ems_window ON event_market_snapshots(event_id, symbol, window_label);
CREATE UNIQUE INDEX idx_mer_event_symbol ON market_event_reactions(event_id, symbol);
CREATE INDEX idx_mer_reaction_type ON market_event_reactions(reaction_type);
CREATE INDEX idx_mer_event_time ON market_event_reactions(event_time_utc);
CREATE UNIQUE INDEX idx_rni_provider_extid ON raw_news_items(provider, external_id);
CREATE INDEX idx_rni_published ON raw_news_items(published_utc);
CREATE INDEX idx_rni_domain ON raw_news_items(source_domain);
CREATE INDEX idx_rni_ingested ON raw_news_items(ingested_utc);
CREATE INDEX idx_nc_first_seen ON news_clusters(first_seen_utc);
CREATE INDEX idx_nc_last_seen ON news_clusters(last_seen_utc);
CREATE INDEX idx_nc_manip ON news_clusters(is_manipulation_suspect);
CREATE INDEX idx_nc_dq_status ON news_clusters(data_quality_status);
CREATE INDEX idx_nc_valid ON news_clusters(is_valid_signal);
CREATE INDEX idx_nci_cluster ON news_cluster_items(cluster_id);
CREATE INDEX idx_nci_item ON news_cluster_items(raw_news_item_id);
CREATE INDEX idx_nam_cluster ON news_asset_mappings(cluster_id);
CREATE INDEX idx_nam_symbol ON news_asset_mappings(symbol);
CREATE UNIQUE INDEX idx_nss_cluster ON news_sentiment_scores(cluster_id);
CREATE INDEX idx_nn_cluster ON news_narratives(cluster_id);
CREATE UNIQUE INDEX idx_nn_cluster_type ON news_narratives(cluster_id, narrative_type);
CREATE INDEX idx_nn_type ON news_narratives(narrative_type);
CREATE INDEX idx_nn_severity ON news_narratives(severity_level);
CREATE INDEX idx_nis_cluster ON news_intelligence_signals(cluster_id);
CREATE INDEX idx_nis_symbol ON news_intelligence_signals(symbol);
CREATE INDEX idx_nis_created ON news_intelligence_signals(created_at);
CREATE INDEX idx_nis_dq_status ON news_intelligence_signals(data_quality_status);
CREATE INDEX idx_nis_valid ON news_intelligence_signals(is_valid_signal);
CREATE INDEX idx_nis_validation_status ON news_intelligence_signals(validation_status);
CREATE INDEX idx_nmr_cluster  ON news_market_reactions(cluster_id);
CREATE INDEX idx_nmr_symbol   ON news_market_reactions(symbol);
CREATE INDEX idx_nmr_accuracy ON news_market_reactions(sentiment_accuracy);
CREATE INDEX idx_nmr_false    ON news_market_reactions(is_false_signal);
CREATE INDEX idx_nmr_created  ON news_market_reactions(created_at);
CREATE INDEX idx_nph_source   ON news_provider_health(source_id);
CREATE INDEX idx_nph_status   ON news_provider_health(status);
CREATE INDEX idx_nph_checked  ON news_provider_health(last_checked_utc);
CREATE INDEX idx_mni_created  ON manual_news_imports(created_at);
CREATE INDEX idx_rtnps_provider ON real_time_news_provider_status(provider);
CREATE INDEX idx_rtnps_status   ON real_time_news_provider_status(health_status);
CREATE INDEX idx_nc_latency_cat  ON news_clusters(latency_category);
CREATE INDEX idx_nc_conflict      ON news_clusters(conflict_flag);
CREATE INDEX idx_nc_fake_risk     ON news_clusters(fake_news_risk_score);
CREATE INDEX idx_nc_mkt_confirm   ON news_clusters(market_confirmation_status);
CREATE INDEX idx_dusd_created ON dynamic_universe_shadow_diagnostics(created_at);
CREATE INDEX idx_dusd_cycle ON dynamic_universe_shadow_diagnostics(cycle_id);
CREATE INDEX idx_dusd_symbol ON dynamic_universe_shadow_diagnostics(symbol);
CREATE INDEX idx_dusd_pass ON dynamic_universe_shadow_diagnostics(would_pass_strategy);
CREATE INDEX idx_symbol_universe_rankings_created ON symbol_universe_rankings(created_at);
CREATE INDEX idx_symbol_universe_rankings_run ON symbol_universe_rankings(ranking_run_id);
CREATE INDEX idx_symbol_universe_rankings_symbol ON symbol_universe_rankings(symbol);
CREATE INDEX idx_symbol_universe_rankings_action ON symbol_universe_rankings(recommended_action);
CREATE INDEX idx_symbol_promotion_decisions_created ON symbol_universe_promotion_decisions(created_at);
CREATE INDEX idx_symbol_promotion_decisions_bot ON symbol_universe_promotion_decisions(bot_instance_id);
CREATE INDEX idx_symbol_promotion_decisions_type ON symbol_universe_promotion_decisions(decision_type);
CREATE INDEX idx_weekly_bot_date ON weekly_snapshots(bot_instance_id, week_start_date);
CREATE INDEX idx_monthly_bot_date ON monthly_snapshots(bot_instance_id, month_start_date);
CREATE INDEX idx_decision_logs_config_symbol ON decision_logs(config_id, symbol);
CREATE UNIQUE INDEX uq_trading_decisions_candle
        ON trading_decisions (
            bot_instance_id, symbol, timeframe, closed_candle_close_time
        )
        WHERE closed_candle_close_time IS NOT NULL
          AND complete = 1
          AND primary_reason <> 'NO_NEW_CANDLE'
        ;
CREATE UNIQUE INDEX uq_readiness_section
        ON readiness_section_confirmations (bot_instance_id, section, policy_hash)
        ;
CREATE INDEX idx_td_bot_time ON trading_decisions(bot_instance_id, evaluated_at);
CREATE INDEX idx_td_cycle ON trading_decisions(cycle_id);
CREATE INDEX idx_td_run ON trading_decisions(run_id);
CREATE INDEX idx_td_reason ON trading_decisions(bot_instance_id, primary_reason);
CREATE INDEX idx_td_incomplete ON trading_decisions(complete, evaluated_at);
CREATE INDEX idx_td_provenance ON trading_decisions(provenance, bot_instance_id);
CREATE INDEX idx_ea_decision ON execution_attempts(decision_id);
CREATE INDEX idx_ea_bot_time ON execution_attempts(bot_instance_id, started_at);
CREATE INDEX idx_pos_bot_symbol ON positions(bot_instance_id, symbol, status);
CREATE INDEX idx_pe_position ON position_events(position_id, occurred_at);
CREATE INDEX idx_pe_bot_type ON position_events(bot_instance_id, event_type);
CREATE INDEX idx_risk_bot_time ON risk_events(bot_instance_id, occurred_at);
CREATE INDEX idx_recon_bot_time ON reconciliation_events(bot_instance_id, occurred_at);
CREATE INDEX idx_dq_type_time ON data_quality_events(event_type, detected_at);
CREATE INDEX idx_cycles_bot_time ON trading_cycles(bot_instance_id, started_at);
CREATE INDEX idx_runs_bot ON bot_runs(bot_instance_id, started_at);
CREATE INDEX idx_ms_symbol_time ON market_snapshots(symbol, timeframe, closed_candle_close_time);
CREATE INDEX idx_thr_bot_time ON threshold_decisions(bot_instance_id, decided_at);
CREATE INDEX idx_thr_symbol ON threshold_decisions(bot_instance_id, symbol, timeframe, closed_candle_time);
CREATE INDEX idx_thr_status ON threshold_decisions(bot_instance_id, status);
CREATE INDEX idx_thr_decision ON threshold_decisions(decision_id);
CREATE INDEX idx_expert_threshold ON expert_evaluations(threshold_decision_id);
CREATE INDEX idx_expert_bot_symbol ON expert_evaluations(bot_instance_id, symbol, closed_candle_time);
CREATE INDEX idx_kyc_cases_user_id ON kyc_cases(user_id);
CREATE INDEX idx_kyc_cases_status ON kyc_cases(status);
CREATE INDEX idx_kyc_profiles_user_id ON kyc_profiles(user_id);
CREATE INDEX idx_kyc_documents_user_id ON kyc_documents(user_id);
CREATE INDEX idx_kyc_documents_case_id ON kyc_documents(kyc_case_id);
CREATE INDEX idx_kyc_selfie_user_id ON kyc_selfie_checks(user_id);
CREATE INDEX idx_kyc_audit_user_id ON kyc_audit_log(user_id);
CREATE INDEX idx_kyc_audit_case_id ON kyc_audit_log(kyc_case_id);
CREATE INDEX idx_kyc_audit_event_type ON kyc_audit_log(event_type);
CREATE INDEX idx_universe_snapshots_bot
    ON universe_snapshots(bot_instance_id, generated_at);
CREATE INDEX idx_cati_resv_account_status_expiry ON cati_portfolio_reservations(broker_account_id, status, expires_at);
CREATE INDEX idx_cati_resv_bot_status ON cati_portfolio_reservations(bot_instance_id, status);
CREATE INDEX idx_cati_resv_status_expiry ON cati_portfolio_reservations(status, expires_at);
CREATE INDEX idx_cati_resv_pending ON cati_portfolio_reservations(status, resolution_deadline);
CREATE INDEX idx_cati_tplan_account_created ON cati_trade_plans(broker_account_id, created_at);
CREATE INDEX idx_cati_tplan_bot_cycle ON cati_trade_plans(bot_instance_id, cycle_id);
CREATE INDEX idx_cati_tplan_reservation ON cati_trade_plans(reservation_id);
CREATE TRIGGER trg_cati_tplan_no_update BEFORE UPDATE ON cati_trade_plans
        BEGIN SELECT RAISE(ABORT, 'cati_trade_plans is append-only'); END;
CREATE TRIGGER trg_cati_tplan_no_delete BEFORE DELETE ON cati_trade_plans
        BEGIN SELECT RAISE(ABORT, 'cati_trade_plans is append-only'); END;
CREATE INDEX idx_cati_pfc_account_time ON cati_position_forecasts(broker_account_id, forecast_time);
CREATE INDEX idx_cati_pfc_position ON cati_position_forecasts(position_id);
CREATE INDEX idx_cati_exd_account_time ON cati_exit_decisions(broker_account_id, decision_time);
CREATE INDEX idx_cati_exd_position ON cati_exit_decisions(position_id);
CREATE INDEX idx_cati_risk_plan ON cati_risk_decisions(trade_plan_id);
CREATE INDEX idx_cati_risk_account_time ON cati_risk_decisions(broker_account_id, decision_time);
CREATE INDEX idx_cati_exec_plan ON cati_execution_attempts(trade_plan_id);
CREATE INDEX idx_cati_exec_account_time ON cati_execution_attempts(broker_account_id, recorded_at);
CREATE INDEX idx_cati_exec_position ON cati_execution_attempts(position_id);
CREATE INDEX idx_cati_err_time ON cati_component_errors(observed_at);
CREATE INDEX idx_cati_dev_opp ON cati_decision_evidence(broker_account_id, economic_opportunity_id);
CREATE INDEX idx_cati_cert_run_stage ON cati_certification_runs(stage, dataset_hash);
CREATE INDEX idx_cati_cert_stage_run ON cati_certification_stage_results(certification_run_id);
CREATE INDEX idx_cati_exp_dataset ON cati_experiment_registry(dataset_hash, policy_hash);
CREATE INDEX idx_cati_holdout_id ON cati_holdout_registry(holdout_id, recorded_at);
CREATE INDEX idx_cati_mlm_role ON cati_ml_models(role, created_at);
CREATE INDEX idx_cati_mle_model ON cati_ml_model_events(model_id, recorded_at);
CREATE INDEX idx_cati_mls_model ON cati_ml_shadow_predictions(model_id, decision_time);
CREATE INDEX idx_cati_mls_cand ON cati_ml_shadow_predictions(setup_candidate_id);
CREATE INDEX idx_cati_phase_time ON cati_promotion_phase_history(recorded_at);
CREATE INDEX idx_cati_scope_acct ON cati_promotion_scopes(broker_account_id, recorded_at);
CREATE INDEX idx_cati_ctrl ON cati_governance_controls(control, scope, recorded_at);
CREATE TRIGGER trg_cati_pfc_no_update BEFORE UPDATE ON cati_position_forecasts
        BEGIN SELECT RAISE(ABORT, 'cati_position_forecasts is append-only'); END;
CREATE TRIGGER trg_cati_pfc_no_delete BEFORE DELETE ON cati_position_forecasts
        BEGIN SELECT RAISE(ABORT, 'cati_position_forecasts is append-only'); END;
CREATE TRIGGER trg_cati_exd_no_update BEFORE UPDATE ON cati_exit_decisions
        BEGIN SELECT RAISE(ABORT, 'cati_exit_decisions is append-only'); END;
CREATE TRIGGER trg_cati_exd_no_delete BEFORE DELETE ON cati_exit_decisions
        BEGIN SELECT RAISE(ABORT, 'cati_exit_decisions is append-only'); END;
CREATE TRIGGER trg_cati_risk_no_update BEFORE UPDATE ON cati_risk_decisions
        BEGIN SELECT RAISE(ABORT, 'cati_risk_decisions is append-only'); END;
CREATE TRIGGER trg_cati_risk_no_delete BEFORE DELETE ON cati_risk_decisions
        BEGIN SELECT RAISE(ABORT, 'cati_risk_decisions is append-only'); END;
CREATE TRIGGER trg_cati_exec_no_update BEFORE UPDATE ON cati_execution_attempts
        BEGIN SELECT RAISE(ABORT, 'cati_execution_attempts is append-only'); END;
CREATE TRIGGER trg_cati_exec_no_delete BEFORE DELETE ON cati_execution_attempts
        BEGIN SELECT RAISE(ABORT, 'cati_execution_attempts is append-only'); END;
CREATE TRIGGER trg_cati_err_no_update BEFORE UPDATE ON cati_component_errors
        BEGIN SELECT RAISE(ABORT, 'cati_component_errors is append-only'); END;
CREATE TRIGGER trg_cati_err_no_delete BEFORE DELETE ON cati_component_errors
        BEGIN SELECT RAISE(ABORT, 'cati_component_errors is append-only'); END;
CREATE TRIGGER trg_cati_dev_no_update BEFORE UPDATE ON cati_decision_evidence
        BEGIN SELECT RAISE(ABORT, 'cati_decision_evidence is append-only'); END;
CREATE TRIGGER trg_cati_dev_no_delete BEFORE DELETE ON cati_decision_evidence
        BEGIN SELECT RAISE(ABORT, 'cati_decision_evidence is append-only'); END;
CREATE TRIGGER trg_cati_crun_no_update BEFORE UPDATE ON cati_certification_runs
        BEGIN SELECT RAISE(ABORT, 'cati_certification_runs is append-only'); END;
CREATE TRIGGER trg_cati_crun_no_delete BEFORE DELETE ON cati_certification_runs
        BEGIN SELECT RAISE(ABORT, 'cati_certification_runs is append-only'); END;
CREATE TRIGGER trg_cati_cstg_no_update BEFORE UPDATE ON cati_certification_stage_results
        BEGIN SELECT RAISE(ABORT, 'cati_certification_stage_results is append-only'); END;
CREATE TRIGGER trg_cati_cstg_no_delete BEFORE DELETE ON cati_certification_stage_results
        BEGIN SELECT RAISE(ABORT, 'cati_certification_stage_results is append-only'); END;
CREATE TRIGGER trg_cati_exp_no_update BEFORE UPDATE ON cati_experiment_registry
        BEGIN SELECT RAISE(ABORT, 'cati_experiment_registry is append-only'); END;
CREATE TRIGGER trg_cati_exp_no_delete BEFORE DELETE ON cati_experiment_registry
        BEGIN SELECT RAISE(ABORT, 'cati_experiment_registry is append-only'); END;
CREATE TRIGGER trg_cati_hold_no_update BEFORE UPDATE ON cati_holdout_registry
        BEGIN SELECT RAISE(ABORT, 'cati_holdout_registry is append-only'); END;
CREATE TRIGGER trg_cati_hold_no_delete BEFORE DELETE ON cati_holdout_registry
        BEGIN SELECT RAISE(ABORT, 'cati_holdout_registry is append-only'); END;
CREATE TRIGGER trg_cati_mlm_no_update BEFORE UPDATE ON cati_ml_models
        BEGIN SELECT RAISE(ABORT, 'cati_ml_models is append-only'); END;
CREATE TRIGGER trg_cati_mlm_no_delete BEFORE DELETE ON cati_ml_models
        BEGIN SELECT RAISE(ABORT, 'cati_ml_models is append-only'); END;
CREATE TRIGGER trg_cati_mle_no_update BEFORE UPDATE ON cati_ml_model_events
        BEGIN SELECT RAISE(ABORT, 'cati_ml_model_events is append-only'); END;
CREATE TRIGGER trg_cati_mle_no_delete BEFORE DELETE ON cati_ml_model_events
        BEGIN SELECT RAISE(ABORT, 'cati_ml_model_events is append-only'); END;
CREATE TRIGGER trg_cati_mls_no_update BEFORE UPDATE ON cati_ml_shadow_predictions
        BEGIN SELECT RAISE(ABORT, 'cati_ml_shadow_predictions is append-only'); END;
CREATE TRIGGER trg_cati_mls_no_delete BEFORE DELETE ON cati_ml_shadow_predictions
        BEGIN SELECT RAISE(ABORT, 'cati_ml_shadow_predictions is append-only'); END;
CREATE TRIGGER trg_cati_phase_no_update BEFORE UPDATE ON cati_promotion_phase_history
        BEGIN SELECT RAISE(ABORT, 'cati_promotion_phase_history is append-only'); END;
CREATE TRIGGER trg_cati_phase_no_delete BEFORE DELETE ON cati_promotion_phase_history
        BEGIN SELECT RAISE(ABORT, 'cati_promotion_phase_history is append-only'); END;
CREATE TRIGGER trg_cati_scope_no_update BEFORE UPDATE ON cati_promotion_scopes
        BEGIN SELECT RAISE(ABORT, 'cati_promotion_scopes is append-only'); END;
CREATE TRIGGER trg_cati_scope_no_delete BEFORE DELETE ON cati_promotion_scopes
        BEGIN SELECT RAISE(ABORT, 'cati_promotion_scopes is append-only'); END;
CREATE TRIGGER trg_cati_ctrl_no_update BEFORE UPDATE ON cati_governance_controls
        BEGIN SELECT RAISE(ABORT, 'cati_governance_controls is append-only'); END;
CREATE TRIGGER trg_cati_ctrl_no_delete BEFORE DELETE ON cati_governance_controls
        BEGIN SELECT RAISE(ABORT, 'cati_governance_controls is append-only'); END;
CREATE INDEX idx_cati_gms_time ON cati_global_market_states(decision_time, timeframe);
CREATE INDEX idx_cati_gms_state ON cati_global_market_states(global_state_id);
CREATE TRIGGER trg_cati_gms_no_update BEFORE UPDATE ON cati_global_market_states
        BEGIN SELECT RAISE(ABORT, 'cati_global_market_states is append-only'); END;
CREATE TRIGGER trg_cati_gms_no_delete BEFORE DELETE ON cati_global_market_states
        BEGIN SELECT RAISE(ABORT, 'cati_global_market_states is append-only'); END;
CREATE INDEX idx_ccpe_account ON cati_capital_plan_evidence(broker_account_id, created_at);
CREATE TRIGGER trg_ccpe_no_update BEFORE UPDATE ON cati_capital_plan_evidence
                             BEGIN SELECT RAISE(ABORT, 'cati_capital_plan_evidence is append-only'); END;
CREATE TRIGGER trg_ccpe_no_delete BEFORE DELETE ON cati_capital_plan_evidence
                             BEGIN SELECT RAISE(ABORT, 'cati_capital_plan_evidence is append-only'); END;
CREATE INDEX idx_btr_account_status ON broker_transfer_requests(broker_account_id, status);
CREATE INDEX idx_btr_user ON broker_transfer_requests(user_id, requested_at);
CREATE INDEX idx_bte_transfer ON broker_transfer_events(transfer_id, id);
CREATE INDEX idx_btrec_account ON broker_transfer_reconciliations(broker_account_id, run_at);
CREATE TRIGGER trg_bte_no_update BEFORE UPDATE ON broker_transfer_events
            BEGIN SELECT RAISE(ABORT, 'broker_transfer_events is append-only'); END;
CREATE TRIGGER trg_bte_no_delete BEFORE DELETE ON broker_transfer_events
            BEGIN SELECT RAISE(ABORT, 'broker_transfer_events is append-only'); END;
CREATE INDEX idx_vi_class ON venue_instruments(venue, environment, asset_class, api_tradable);
CREATE INDEX idx_mc_canon ON market_candles(canonical_symbol, timeframe, open_time);
CREATE INDEX idx_mfo_feature ON market_feature_observations(canonical_symbol, feature, observed_at);
CREATE INDEX idx_fxq_pair ON fx_reference_quotes(pair, timeframe, open_time);
CREATE TRIGGER trg_dataset_manifests_no_update BEFORE UPDATE ON dataset_manifests
                             BEGIN SELECT RAISE(ABORT, 'dataset_manifests is immutable'); END;
CREATE TRIGGER trg_dataset_manifests_no_delete BEFORE DELETE ON dataset_manifests
                             BEGIN SELECT RAISE(ABORT, 'dataset_manifests is immutable'); END;
CREATE TRIGGER trg_universe_manifests_no_update BEFORE UPDATE ON universe_manifests
                             BEGIN SELECT RAISE(ABORT, 'universe_manifests is immutable'); END;
CREATE TRIGGER trg_universe_manifests_no_delete BEFORE DELETE ON universe_manifests
                             BEGIN SELECT RAISE(ABORT, 'universe_manifests is immutable'); END;
CREATE TRIGGER trg_fx_reference_repairs_no_update BEFORE UPDATE ON fx_reference_repairs
                             BEGIN SELECT RAISE(ABORT, 'fx_reference_repairs is immutable'); END;
CREATE TRIGGER trg_fx_reference_repairs_no_delete BEFORE DELETE ON fx_reference_repairs
                             BEGIN SELECT RAISE(ABORT, 'fx_reference_repairs is immutable'); END;
CREATE INDEX idx_event_news_mode_decisions_created ON event_news_mode_decisions(created_at);
CREATE INDEX idx_event_news_mode_decisions_type ON event_news_mode_decisions(decision_type);
CREATE INDEX idx_event_news_influence_created ON event_news_influence_decisions(created_at);
CREATE INDEX idx_event_news_influence_trace ON event_news_influence_decisions(trace_id);
CREATE INDEX idx_event_news_influence_symbol ON event_news_influence_decisions(symbol);
CREATE INDEX idx_event_news_influence_action ON event_news_influence_decisions(applied_action);
DELETE FROM "sqlite_sequence";
INSERT INTO "sqlite_sequence" VALUES('broker_credentials_v2',0);
INSERT INTO "sqlite_sequence" VALUES('real_time_news_provider_status',4);
INSERT INTO "sqlite_sequence" VALUES('weekly_snapshots',0);
INSERT INTO "sqlite_sequence" VALUES('monthly_snapshots',0);
INSERT INTO "sqlite_sequence" VALUES('event_news_mode_decisions',1);
COMMIT;
